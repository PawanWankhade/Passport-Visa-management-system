﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;


using MainDllLibrary;
//starts from here.....
public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        Credentials credits = new Credentials();
        credits.uid = txtUserid.Text;
        credits.password = txtPassword.Text;
        UserConnection ucon = new UserConnection();
        bool isValidUser = false;
        try
        {
            string s = ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString;

            ucon.OpenConnection(s);

            isValidUser = ucon.ValidateUser(credits);
            if (isValidUser)
            {
                Session["uid"] = credits.uid;
                Response.Redirect("~/User/WelcomeUser.aspx");

            }
            else if (txtUserid.Text == "" || txtPassword.Text == "")
            {
                lblError.Text = "Please enter your Userid and password";
                lblError.ForeColor = System.Drawing.Color.Red;
            }
            else if (!isValidUser)
            {
                lblError.Text = "Please check your Userid and password";
                lblError.ForeColor = System.Drawing.Color.Red;
            }
            else
                lblError.Text = "";



            ucon.CloseConnection();

        }
        catch (Exception)
        {

            throw;
        }


    }
}