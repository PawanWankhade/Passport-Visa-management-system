﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MainDllLibrary;
using System.Configuration;

public partial class User_ChangePassword : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void apbtnSave_Click(object sender, EventArgs e)
    {

    }
    protected void fpbtnSave_Click(object sender, EventArgs e)
    {
        User u = new User();
        u.Uid = cptxtUserid.Text;
        u.Email = cptxtEmail.Text;
        u.Question = cpddlHintque.SelectedItem.Text;
        u.Answer = cptxtHintans.Text;


        UserConnection ucon = new UserConnection();
        string s = ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString;

        ucon.OpenConnection(s);
        bool b = ucon.ValidateUserDetails(u);
        if (b == true)
        {
            Credentials c = new Credentials();
            Credentials c1 = c.NewPassword();
            c1.uid = cptxtUserid.Text;
            bool flag = ucon.updateforgotpassword(c1);
            if (flag == true)
            {
                Session["pass"] = c1.password;
                Response.Redirect("~/Success.aspx?type=forgotPassword");
                
            }
            else
                lblerr.Text = "";
        }
        else
        {
            lblerr.Text = "Please enter valid details";
            lblerr.ForeColor = System.Drawing.Color.Red;
        }
        ucon.CloseConnection();
    }
    protected void cpbtnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
}