﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MainDllLibrary;
using System.Data.SqlClient;
using System.Configuration;

namespace PassportSevaNew
{
    public partial class ApplyVisa : Form
    {
        public string userid1;
       
        Passport p = new Passport();
        public ApplyVisa(string userid)
        {
            InitializeComponent();
            
            panel1.Visible = true;
            panel2.Visible = false;          
            userid1=userid;
            
        }

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            bool flag1 = true;
            // code for validation
            if (txtpassportno.Text == "")
            {
                flag1 = false;
            }
         
            if (flag1 == true)
            {
                
                PassportConnect pc = new PassportConnect();
                string s = ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString;
                pc.OpenConnection(s);

                if (userid1 != null)
                {

                    p = pc.GetPassportByPid(txtpassportno.Text, userid1);
                    if (p.PID != null)
                    {
                        panel2.Visible = true;
                        panel1.Visible = false;
                        txtuserid.Text = p.Uid;
                        GenerateFields fields = new GenerateFields();
                        string sql = ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString;
                        fields.OpenConnection(sql);

                        DataSet ds = fields.GetCountries();
                        combocountry.DataSource = ds;
                        combocountry.DataSource = ds.Tables[0];
                        combocountry.ValueMember = "cid";
                        combocountry.DisplayMember = "cname";
                        fields.CloseConnection();

                        fields = new GenerateFields();
                        fields.OpenConnection(sql);
                        ds = fields.GetOccupation();
                        combooccupation.DataSource = ds.Tables[0];
                        combooccupation.DisplayMember = "occname";
                        fields.CloseConnection();

                    }
                    else
                    {
                        MessageBox.Show("Passport ID does not exist");
                    }
                }
                else
                {
                    MessageBox.Show("First Login");
                   
                }
                pc.CloseConnection();
            }
            else
                MessageBox.Show("Please enter your passport Id");
        }

        private void btnvisasubmit_Click_1(object sender, EventArgs e)
        {
            bool flag1 = true,flag2=true;
           

            if (combocountry.SelectedItem == null || combooccupation.SelectedItem == null)
            {
                flag2 = false;
            }
            else
                flag2 = true;

            if (flag1 == true && flag2==true)
            {

                Visa visa = new Visa();
                visa.Country = combocountry.Text;
                visa.Occupation = combooccupation.Text;
                visa.ApplyDate = DateTime.Now;
                visa.IssueDate = (DateTime.Now).AddDays(10);
                visa.ExpiryDate = (DateTime.Now).AddYears(10);

                if (userid1 != null || userid1 != "")
                {
                    visa.Uid = userid1;

                }
                else
                {
                    LoginUser l = new LoginUser();
                    l.Show();
                    this.Hide();
                }

                if (p.PID != null)
                {
                    visa.PID = p.PID;
                }
                else
                {
                    Error er = new Error();
                    er.Show();
                    this.Hide();
                }

                VisaConnect connect = new VisaConnect();
                string sql = ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString;
                connect.OpenConnection(sql);
                Visa credits = new Visa();
                if (userid1 != null)
                {
                    credits = connect.InsertVisa(visa);
                }
                else
                {
                    MessageBox.Show("First Login");

                }
                if (credits.VID != null)
                {

                    Success s1 = new Success(visa.VID, visa.ExpiryDate, visa.Amount,visa.Uid);
                    s1.Show();
                    this.Hide();

                }
                else
                {
                    MessageBox.Show("Registration failed!!!");
                }

                connect.CloseConnection();
            }

            else
                MessageBox.Show("Please enter all the required fields");
        }

      

        private void btnvisacancel_Click(object sender, EventArgs e)
        {
            Home h = new Home();
            h.Show();
            this.Hide();

        }

        private void hbtnapply_Click(object sender, EventArgs e)
        {
            ApplyPassport ap = new ApplyPassport(userid1);
            ap.Show();
            this.Hide();
        }

       

        private void hbtnrisspass_Click(object sender, EventArgs e)
        {
            ReissuePassport rp = new ReissuePassport(userid1);
            rp.Show();
            this.Hide();
        }

        private void hbtnapplyvisa_Click(object sender, EventArgs e)
        {
            ApplyVisa av = new ApplyVisa(userid1);
            av.Show();
            this.Hide();
        }

        private void hbtnvisacncl_Click(object sender, EventArgs e)
        {
            VisaCancellation vc = new VisaCancellation(userid1);
            vc.Show();
            this.Hide();
        }

        private void hbtnchnfpass_Click(object sender, EventArgs e)
        {
            ChangePassword c = new ChangePassword(userid1);
            c.Show();
            this.Hide();
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            Home h = new Home();
            h.Show();
            this.Hide();
        }

     
        }

       
    }

