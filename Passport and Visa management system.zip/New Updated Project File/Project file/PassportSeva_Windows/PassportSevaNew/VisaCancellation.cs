﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MainDllLibrary;
using System.Configuration;

namespace PassportSevaNew
{
    public partial class VisaCancellation : Form
    {

        public string userid = "";
        public VisaCancellation(string uid)
        {

            InitializeComponent();
            panel1.Visible = true;
            panel2.Visible = false;
            txtuserid2.Text = txtuserid.Text;
            userid = uid;
            
            ddlhintque.Items.Add("Who is your favourite actor?");
            ddlhintque.Items.Add("Who is your first maths teacher?");
            ddlhintque.Items.Add("What is your favourite game?");
            ddlhintque.Items.Add("What is your mother's maiden name?");
        }


        private void btnsubmit_Click_1(object sender, EventArgs e)
        {
            bool flag1 = true;



            if (txtuserid.Text == "" || txtemailid.Text == "" || txthintans.Text == "" || ddlhintque.SelectedItem == null)
            {
                flag1 = false;
            }
            else
                flag1 = true;

            if (flag1 == true)
            {


                //panel1.Visible = false;
                //panel2.Visible = true;
                User user = new User();
                user.Uid = txtuserid.Text;
                user.Question = ddlhintque.SelectedItem.ToString();
                user.Answer = txthintans.Text;
                user.Email = txtemailid.Text;
                txtuserid2.Text = txtuserid.Text;


                UserConnection ucon = new UserConnection();

                string s = ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString;
                ucon.OpenConnection(s);

                bool flag = ucon.ValidateUserDetails(user);

                if (flag)
                {
                    panel1.Visible = false;
                    panel2.Visible = true;



                }
                else
                {
                    lblerr.Text = "Please check credentials";
                    lblerr.ForeColor = System.Drawing.Color.Red;

                }

                ucon.CloseConnection();
            }

            else
                MessageBox.Show("Please enter all the required fields");
        }

        private void lblcancel_Click(object sender, EventArgs e)
        {
            Home h = new Home();
            h.Show();
            this.Hide();
        }

        private void btncancel2_Click(object sender, EventArgs e)
        {
            Home h = new Home();
            h.Show();
            this.Hide();
        }

        private void vcbtnhome_Click(object sender, EventArgs e)
        {
            Home h = new Home();
            h.Show();
            this.Hide();
        }

        private void hbtnapply_Click(object sender, EventArgs e)
        {
            ApplyPassport ap = new ApplyPassport(userid);
            ap.Show();
            this.Hide();
        }

        private void hbtnrisspass_Click(object sender, EventArgs e)
        {
            ReissuePassport rp = new ReissuePassport(userid);
            rp.Show();
            this.Hide();
        }

        private void hbtnapplyvisa_Click(object sender, EventArgs e)
        {
            ApplyVisa av = new ApplyVisa(userid);
            av.Show();
            this.Hide();
        }

        private void hbtnvisacncl_Click(object sender, EventArgs e)
        {
            VisaCancellation vc = new VisaCancellation(userid);
            vc.Show();
            this.Hide();
        }

        private void hbtnchnfpass_Click(object sender, EventArgs e)
        {
            ChangePassword c = new ChangePassword(userid);
            c.Show();
            this.Hide();
        }

        private void btncancel2_Click_1(object sender, EventArgs e)
        {
            Home h = new Home();
            h.Show();
            this.Hide();
        }

        private void lblcancel_Click_1(object sender, EventArgs e)
        {
            Home h = new Home();
            h.Show();
            this.Hide();
        }

        private void btnsubmit2_Click(object sender, EventArgs e)
        {
            bool flag2 = true;
            if (txtuserid2.Text == "" || txtvisaid.Text == "" || txtpassportid.Text == "")
            {
                flag2 = false;
            }

            if (flag2 == true)
            {
                Visa visa = new Visa();
                visa.VID = txtvisaid.Text;
                visa.PID = txtpassportid.Text;
                visa.Uid = txtuserid.Text;



                VisaConnect vconnect = new VisaConnect();

                string s = ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString;
                vconnect.OpenConnection(s);

                bool validateFlag = vconnect.ValidateVisa(visa);

                if (validateFlag)
                {
                    lblerr2.Text = "";
                    double updateFlag = vconnect.CancleVisa(visa.VID, visa.Uid);
                    if (updateFlag > 0)
                    {
                        lblerr2.Text = "Visa Cancelled Successfully";
                        this.Hide();

                        Success success = new Success(updateFlag,visa.Uid);

                        success.Show();
                      

                        lblerr2.ForeColor = System.Drawing.Color.Green;
                    }
                    if (updateFlag == -1)
                    {
                        //Visa not found

                        MessageBox.Show("Visa not found");

                        //this.Hide();
                        //Error error = new Error();
                        //error.Show();
                      
                    }
                    if (updateFlag == -2)
                    {
                        
                        this.Hide();
                        Error error = new Error();
                        this.Show();
                      
                    }



                }
                else
                {
                    lblerr2.Text = "Visa record not found";
                    lblerr2.ForeColor = System.Drawing.Color.Red;
                }

                vconnect.CloseConnection();

            }

            else
                MessageBox.Show("Please enter all the required fields");
        }

      

        
       
    }


}

