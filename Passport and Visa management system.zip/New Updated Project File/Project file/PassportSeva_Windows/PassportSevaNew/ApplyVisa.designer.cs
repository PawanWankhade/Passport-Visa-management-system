﻿namespace PassportSevaNew
{
    partial class ApplyVisa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ApplyVisa));
            this.txtpassportno = new System.Windows.Forms.TextBox();
            this.btnsubmit = new System.Windows.Forms.Button();
            this.btncancel = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblpassportno = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.combooccupation = new System.Windows.Forms.ComboBox();
            this.combocountry = new System.Windows.Forms.ComboBox();
            this.btnvisacancel = new System.Windows.Forms.Button();
            this.btnvisasubmit = new System.Windows.Forms.Button();
            this.txtuserid = new System.Windows.Forms.TextBox();
            this.lbloccupation = new System.Windows.Forms.Label();
            this.lblcountry = new System.Windows.Forms.Label();
            this.lbltxtuserid = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.hbtnchnfpass = new System.Windows.Forms.Button();
            this.hbtnrisspass = new System.Windows.Forms.Button();
            this.hbtnapplyvisa = new System.Windows.Forms.Button();
            this.hbtnvisacncl = new System.Windows.Forms.Button();
            this.hbtnapply = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtpassportno
            // 
            this.txtpassportno.Location = new System.Drawing.Point(125, 23);
            this.txtpassportno.Name = "txtpassportno";
            this.txtpassportno.Size = new System.Drawing.Size(140, 20);
            this.txtpassportno.TabIndex = 1;
            // 
            // btnsubmit
            // 
            this.btnsubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsubmit.Location = new System.Drawing.Point(28, 87);
            this.btnsubmit.Name = "btnsubmit";
            this.btnsubmit.Size = new System.Drawing.Size(75, 23);
            this.btnsubmit.TabIndex = 2;
            this.btnsubmit.Text = "Submit";
            this.btnsubmit.UseVisualStyleBackColor = true;
            this.btnsubmit.Click += new System.EventHandler(this.btnsubmit_Click);
            // 
            // btncancel
            // 
            this.btncancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncancel.Location = new System.Drawing.Point(132, 87);
            this.btncancel.Name = "btncancel";
            this.btncancel.Size = new System.Drawing.Size(75, 23);
            this.btncancel.TabIndex = 3;
            this.btncancel.Text = "cancel";
            this.btncancel.UseVisualStyleBackColor = true;
            this.btncancel.Click += new System.EventHandler(this.btncancel_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lblpassportno);
            this.panel1.Controls.Add(this.btnsubmit);
            this.panel1.Controls.Add(this.btncancel);
            this.panel1.Controls.Add(this.txtpassportno);
            this.panel1.Location = new System.Drawing.Point(250, 187);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(293, 417);
            this.panel1.TabIndex = 4;
            // 
            // lblpassportno
            // 
            this.lblpassportno.AutoSize = true;
            this.lblpassportno.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpassportno.Location = new System.Drawing.Point(3, 24);
            this.lblpassportno.Name = "lblpassportno";
            this.lblpassportno.Size = new System.Drawing.Size(113, 16);
            this.lblpassportno.TabIndex = 2;
            this.lblpassportno.Text = "Passport Number";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.combooccupation);
            this.panel2.Controls.Add(this.combocountry);
            this.panel2.Controls.Add(this.btnvisacancel);
            this.panel2.Controls.Add(this.btnvisasubmit);
            this.panel2.Controls.Add(this.txtuserid);
            this.panel2.Controls.Add(this.lbloccupation);
            this.panel2.Controls.Add(this.lblcountry);
            this.panel2.Controls.Add(this.lbltxtuserid);
            this.panel2.Location = new System.Drawing.Point(284, 187);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(547, 327);
            this.panel2.TabIndex = 5;
            // 
            // combooccupation
            // 
            this.combooccupation.FormattingEnabled = true;
            this.combooccupation.Location = new System.Drawing.Point(155, 158);
            this.combooccupation.Name = "combooccupation";
            this.combooccupation.Size = new System.Drawing.Size(140, 21);
            this.combooccupation.TabIndex = 4;
            // 
            // combocountry
            // 
            this.combocountry.FormattingEnabled = true;
            this.combocountry.Location = new System.Drawing.Point(155, 100);
            this.combocountry.Name = "combocountry";
            this.combocountry.Size = new System.Drawing.Size(140, 21);
            this.combocountry.TabIndex = 3;
            // 
            // btnvisacancel
            // 
            this.btnvisacancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnvisacancel.Location = new System.Drawing.Point(184, 234);
            this.btnvisacancel.Name = "btnvisacancel";
            this.btnvisacancel.Size = new System.Drawing.Size(75, 23);
            this.btnvisacancel.TabIndex = 6;
            this.btnvisacancel.Text = "Cancel";
            this.btnvisacancel.UseVisualStyleBackColor = true;
            this.btnvisacancel.Click += new System.EventHandler(this.btnvisacancel_Click);
            // 
            // btnvisasubmit
            // 
            this.btnvisasubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnvisasubmit.Location = new System.Drawing.Point(51, 234);
            this.btnvisasubmit.Name = "btnvisasubmit";
            this.btnvisasubmit.Size = new System.Drawing.Size(75, 23);
            this.btnvisasubmit.TabIndex = 5;
            this.btnvisasubmit.Text = "Submit";
            this.btnvisasubmit.UseVisualStyleBackColor = true;
            this.btnvisasubmit.Click += new System.EventHandler(this.btnvisasubmit_Click_1);
            // 
            // txtuserid
            // 
            this.txtuserid.Enabled = false;
            this.txtuserid.Location = new System.Drawing.Point(155, 46);
            this.txtuserid.Name = "txtuserid";
            this.txtuserid.Size = new System.Drawing.Size(140, 20);
            this.txtuserid.TabIndex = 2;
            // 
            // lbloccupation
            // 
            this.lbloccupation.AutoSize = true;
            this.lbloccupation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbloccupation.Location = new System.Drawing.Point(34, 163);
            this.lbloccupation.Name = "lbloccupation";
            this.lbloccupation.Size = new System.Drawing.Size(76, 16);
            this.lbloccupation.TabIndex = 2;
            this.lbloccupation.Text = "Occupation";
            // 
            // lblcountry
            // 
            this.lblcountry.AutoSize = true;
            this.lblcountry.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcountry.Location = new System.Drawing.Point(34, 105);
            this.lblcountry.Name = "lblcountry";
            this.lblcountry.Size = new System.Drawing.Size(53, 16);
            this.lblcountry.TabIndex = 1;
            this.lblcountry.Text = "Country";
            // 
            // lbltxtuserid
            // 
            this.lbltxtuserid.AutoSize = true;
            this.lbltxtuserid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltxtuserid.Location = new System.Drawing.Point(34, 50);
            this.lbltxtuserid.Name = "lbltxtuserid";
            this.lbltxtuserid.Size = new System.Drawing.Size(51, 16);
            this.lbltxtuserid.TabIndex = 0;
            this.lbltxtuserid.Text = "User Id";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(57, 232);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 13);
            this.label2.TabIndex = 6;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.hbtnchnfpass);
            this.panel3.Controls.Add(this.hbtnrisspass);
            this.panel3.Controls.Add(this.hbtnapplyvisa);
            this.panel3.Controls.Add(this.hbtnvisacncl);
            this.panel3.Controls.Add(this.hbtnapply);
            this.panel3.Location = new System.Drawing.Point(3, 187);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(219, 429);
            this.panel3.TabIndex = 53;
            // 
            // hbtnchnfpass
            // 
            this.hbtnchnfpass.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hbtnchnfpass.Location = new System.Drawing.Point(9, 293);
            this.hbtnchnfpass.Name = "hbtnchnfpass";
            this.hbtnchnfpass.Size = new System.Drawing.Size(140, 30);
            this.hbtnchnfpass.TabIndex = 5;
            this.hbtnchnfpass.Text = "Change Password";
            this.hbtnchnfpass.UseVisualStyleBackColor = true;
            this.hbtnchnfpass.Click += new System.EventHandler(this.hbtnchnfpass_Click);
            // 
            // hbtnrisspass
            // 
            this.hbtnrisspass.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hbtnrisspass.Location = new System.Drawing.Point(9, 93);
            this.hbtnrisspass.Name = "hbtnrisspass";
            this.hbtnrisspass.Size = new System.Drawing.Size(140, 30);
            this.hbtnrisspass.TabIndex = 4;
            this.hbtnrisspass.Text = "Reissue Passport";
            this.hbtnrisspass.UseVisualStyleBackColor = true;
            this.hbtnrisspass.Click += new System.EventHandler(this.hbtnrisspass_Click);
            // 
            // hbtnapplyvisa
            // 
            this.hbtnapplyvisa.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hbtnapplyvisa.Location = new System.Drawing.Point(9, 157);
            this.hbtnapplyvisa.Name = "hbtnapplyvisa";
            this.hbtnapplyvisa.Size = new System.Drawing.Size(140, 30);
            this.hbtnapplyvisa.TabIndex = 3;
            this.hbtnapplyvisa.Text = "Apply for Visa";
            this.hbtnapplyvisa.UseVisualStyleBackColor = true;
            this.hbtnapplyvisa.Click += new System.EventHandler(this.hbtnapplyvisa_Click);
            // 
            // hbtnvisacncl
            // 
            this.hbtnvisacncl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hbtnvisacncl.Location = new System.Drawing.Point(9, 224);
            this.hbtnvisacncl.Name = "hbtnvisacncl";
            this.hbtnvisacncl.Size = new System.Drawing.Size(140, 30);
            this.hbtnvisacncl.TabIndex = 2;
            this.hbtnvisacncl.Text = "Visa Cancellation";
            this.hbtnvisacncl.UseVisualStyleBackColor = true;
            this.hbtnvisacncl.Click += new System.EventHandler(this.hbtnvisacncl_Click);
            // 
            // hbtnapply
            // 
            this.hbtnapply.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hbtnapply.Location = new System.Drawing.Point(9, 36);
            this.hbtnapply.Name = "hbtnapply";
            this.hbtnapply.Size = new System.Drawing.Size(140, 30);
            this.hbtnapply.TabIndex = 1;
            this.hbtnapply.Text = "Apply for Passport";
            this.hbtnapply.UseVisualStyleBackColor = true;
            this.hbtnapply.Click += new System.EventHandler(this.hbtnapply_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(246, 130);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 24);
            this.label1.TabIndex = 56;
            this.label1.Text = "Apply for Visa";
            // 
            // lineShape1
            // 
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 243;
            this.lineShape1.X2 = 1098;
            this.lineShape1.Y1 = 171;
            this.lineShape1.Y2 = 178;
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(1108, 616);
            this.shapeContainer1.TabIndex = 57;
            this.shapeContainer1.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Image = ((System.Drawing.Image)(resources.GetObject("label3.Image")));
            this.label3.Location = new System.Drawing.Point(25, 45);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(353, 25);
            this.label3.TabIndex = 40;
            this.label3.Text = "Passport Visa Processing Solutions";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::PassportSevaNew.Properties.Resources.header2;
            this.pictureBox1.Location = new System.Drawing.Point(-2, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1110, 112);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 39;
            this.pictureBox1.TabStop = false;
            // 
            // ApplyVisa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(884, 612);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.shapeContainer1);
            this.Location = new System.Drawing.Point(30, 30);
            this.MaximumSize = new System.Drawing.Size(900, 650);
            this.Name = "ApplyVisa";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Apply for Visa";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtpassportno;
        private System.Windows.Forms.Button btnsubmit;
        private System.Windows.Forms.Button btncancel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblpassportno;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ComboBox combooccupation;
        private System.Windows.Forms.ComboBox combocountry;
        private System.Windows.Forms.Button btnvisacancel;
        private System.Windows.Forms.Button btnvisasubmit;
        private System.Windows.Forms.TextBox txtuserid;
        private System.Windows.Forms.Label lbloccupation;
        private System.Windows.Forms.Label lblcountry;
        private System.Windows.Forms.Label lbltxtuserid;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button hbtnchnfpass;
        private System.Windows.Forms.Button hbtnrisspass;
        private System.Windows.Forms.Button hbtnapplyvisa;
        private System.Windows.Forms.Button hbtnvisacncl;
        private System.Windows.Forms.Button hbtnapply;
        private System.Windows.Forms.Label label1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
    }
}