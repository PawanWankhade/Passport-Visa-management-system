﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PassportSevaNew
{
    public partial class Success : Form
    {
        //change password
        string userid = "";
        public Success()
        {
            InitializeComponent();
            label1.Text="Password changed successfully";
            panel1.Visible = true;
            sbtnhome.Visible = false;
            panel2.Visible = false;
        }

        //visa cancellation
        public Success(double d,string uid)
        {
            InitializeComponent();
            userid = uid;
            label1.Text = "Visa Cancelled successfully ";
            label1.Text += "Amount to be paid:";
            label1.Text +=  d.ToString();
            panel1.Visible = false;
            panel2.Visible = true;
        }

        //after registration
        public Success(string uid, string pswd)
        {
            
                InitializeComponent();
                label1.Text = "Your User ID is : ";
                label1.Text += uid.ToString();
                label2.Text = " Your password is : ";
                label2.Text += pswd;
                panel1.Visible = true;
                panel2.Visible = false;
            }

        //forgot password
        public Success(string pswd)
        {
            InitializeComponent();

            label2.Text = " Your new password is : ";
            label2.Text += pswd;
            panel1.Visible = true;
            panel2.Visible = false;
        }

        //reissue Passport
        public Success(string pid, int amount, DateTime expiry,string uid)
        {
            InitializeComponent();
            userid = uid;
            label1.Text = "Passport ID is ";
            label1.Text += pid + "\n";
            label1.Text += " Amount to be paid= ";
            label1.Text += amount +"\n";
            label1.Text += "Expiry Date is ";
            label1.Text += expiry;
            panel1.Visible = false;
            panel2.Visible = true;
        }

        //apply passport

        public Success(string pid, double amount, DateTime expiry,string uid)
        {
            InitializeComponent();
            userid = uid;
            label1.Text = "Passport ID is ";
            label1.Text += pid + "\n";
            label1.Text += " Amount to be paid= ";
            label1.Text += amount + "\n";
            label1.Text += "Expiry Date is ";
            label1.Text += expiry;
            panel1.Visible = false;
            panel2.Visible = true;
        }


            //Apply for Visa
        public Success(string vid, DateTime expiry, double amount,string uid)
        {
            InitializeComponent();
            userid = uid;
            label1.Text = "Visa ID is ";
            label1.Text += vid + "\n";
             label1.Text += "Expiry Date is ";
             label1.Text += expiry + "\n";
            label1.Text += " Amount to be paid= ";
            label1.Text += amount ;
            panel1.Visible = false;
            panel2.Visible = true;
           
        }


        private void lnklbllogin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            LoginUser lu1 = new LoginUser();
            lu1.Show();
            this.Hide();
        }

        private void sbtnhome_Click(object sender, EventArgs e)
        {
            Home h = new Home(userid);
            h.Show();
            this.Hide();
        }
    }
}
