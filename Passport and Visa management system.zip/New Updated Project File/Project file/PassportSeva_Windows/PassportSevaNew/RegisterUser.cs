﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MainDllLibrary;
using System.Text.RegularExpressions;
using System.Configuration;

namespace PassportSevaNew
{
    public partial class RegisterUser : Form
    {
        public bool flag1 = true,flag2=true,flag3=true,flag4=true,flag5=true,flag6=true;
        public RegisterUser()
        {
            InitializeComponent();
          
            comboQualification.Items.Add("Under Graduate");
            comboQualification.Items.Add("Graduate");
            comboQualification.Items.Add("Post Graduate");
       
            comboSecurity.Items.Add("Who is your favourite actor?");
            comboSecurity.Items.Add("Who is your first Maths teacher?");
            comboSecurity.Items.Add("What is your favourite game?");
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
          

            //validation for required fields
            if (txtAddress.Text == "" || txtAnswer.Text == "" || txtContact.Text == "" || txtEmail.Text == "" || txtFname.Text == "" || txtLname.Text == "" || comboQualification.SelectedItem == null || comboSecurity.SelectedItem == null || !(rdbtnFemale.Checked || rdbtnmale.Checked))
            {
                flag1 = false;
                
            }
            else
                flag1=true;

           

          //validation for first name
            Regex r = new Regex("^([a-zA-Z]+( [a-zA-Z]+)*)$");

            if (!(r.IsMatch(txtFname.Text)) )
            {

                errfname.Text = "First name should contain alphabets only";
                errfname.ForeColor = System.Drawing.Color.Red;
                flag2 = false;
            }

            else
            {
                errfname.Text = "";
               flag2 = true;
            }

            //validation for last name
            if (!(r.IsMatch(txtLname.Text)))
            {
                errlname.Text = "Last name should contain alphabets only";
                errlname.ForeColor = System.Drawing.Color.Red;
                flag3 = false;
            }
            else
            {
                errlname.Text = "";
               flag3 = true;
            }

            //validation for date of birth
            if (dtpickerdob.Value > DateTime.Now)
            {
                errdob.Text = "Please enter a valid date";
                errdob.ForeColor = System.Drawing.Color.Red;
                flag4 = false;
            }
            else
            {
                errdob.Text = "";
                flag4 = true;
            }

            //validation for contact number
            Regex r1 = new Regex("^[0-9]+$");

            if (!(r1.IsMatch(txtContact.Text)))
            {
                errcontact.Text = "Please enter valid contact number";
                errcontact.ForeColor = System.Drawing.Color.Red;
                flag5 = false;
            }
            else
            {
                errcontact.Text = "";
                flag5=true;
            }

            //validation for email
            Regex email = new Regex(@"^[a-z0-9][-a-z0-9.]+@([-a-z0-9]+\.)+[a-z]{2,5}$");
            if (!(email.IsMatch(txtEmail.Text)))
            {
                erremail.Text = "Please enter a valid email Id";
                erremail.ForeColor = System.Drawing.Color.Red;
                flag6 = false;
            }
            else
            {
                erremail.Text = "";
                flag6 = true;
            }

            if (flag1 == true && flag2 == true&&flag3 == true&&flag4 == true&&flag5 == true&&flag6 == true )
            {
                Credentials credit = new Credentials();
                bool flag = true;
                User user = new User();
                user.Address = txtAddress.Text;
                user.Answer = txtAnswer.Text;
                user.Contact = txtContact.Text;
                user.Fname = txtFname.Text;
                user.Lname = txtLname.Text;
                user.Email = txtEmail.Text;
                if (rdbtnmale.Checked)
                    user.Gender = rdbtnmale.Text;
                if (rdbtnFemale.Checked)
                    user.Gender = rdbtnFemale.Text;
                user.Dob = Convert.ToDateTime(dtpickerdob.Text);
                user.Qualification = this.comboQualification.GetItemText(this.comboQualification.SelectedItem);
                user.Question = this.comboSecurity.GetItemText(this.comboSecurity.SelectedItem);

                UserConnection ucon = new UserConnection();
                try
                {
                    string s = ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString;

                    ucon.OpenConnection(s);
                    credit = ucon.RegisterUser(user);

                }
                catch (Exception ex)
                {
                    
                    flag = false;
                    
                }

                finally
                {
                    ucon.CloseConnection();
                }

                if (flag)
                {

                    Success s = new Success(credit.uid, credit.password);
                    s.Show();
                    this.Hide();

                  
                }
                else
                    MessageBox.Show("Error in registration");



                
            }
            
            else
            {
                MessageBox.Show("Please fill all the required fields properly");
            }
        }

      
        private void btnhome_Click(object sender, EventArgs e)
        {
            LoginUser l = new LoginUser();
            l.Show();
            this.Hide();
        }

      

        

      

      
           
       

      

        private void btnCancel_Click(object sender, EventArgs e)
        {
            LoginUser l = new LoginUser();
            l.Show();
            this.Hide();
        }

       
      
    }
}
