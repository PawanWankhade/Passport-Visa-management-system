﻿namespace PassportSevaNew
{
    partial class ForgotPassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ForgotPassword));
            this.fplbluid = new System.Windows.Forms.Label();
            this.fplblque = new System.Windows.Forms.Label();
            this.fplblans = new System.Windows.Forms.Label();
            this.fptxtuid = new System.Windows.Forms.TextBox();
            this.fptxtans = new System.Windows.Forms.TextBox();
            this.fpcomboque = new System.Windows.Forms.ComboBox();
            this.btnsubmit = new System.Windows.Forms.Button();
            this.btncancel = new System.Windows.Forms.Button();
            this.fplblemail = new System.Windows.Forms.Label();
            this.fptxtemail = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // fplbluid
            // 
            this.fplbluid.AutoSize = true;
            this.fplbluid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fplbluid.Location = new System.Drawing.Point(21, 13);
            this.fplbluid.Name = "fplbluid";
            this.fplbluid.Size = new System.Drawing.Size(53, 16);
            this.fplbluid.TabIndex = 0;
            this.fplbluid.Text = "User ID";
            // 
            // fplblque
            // 
            this.fplblque.AutoSize = true;
            this.fplblque.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fplblque.Location = new System.Drawing.Point(20, 96);
            this.fplblque.Name = "fplblque";
            this.fplblque.Size = new System.Drawing.Size(112, 16);
            this.fplblque.TabIndex = 1;
            this.fplblque.Text = "Security Question";
            // 
            // fplblans
            // 
            this.fplblans.AutoSize = true;
            this.fplblans.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fplblans.Location = new System.Drawing.Point(21, 137);
            this.fplblans.Name = "fplblans";
            this.fplblans.Size = new System.Drawing.Size(52, 16);
            this.fplblans.TabIndex = 2;
            this.fplblans.Text = "Answer";
            // 
            // fptxtuid
            // 
            this.fptxtuid.Location = new System.Drawing.Point(133, 13);
            this.fptxtuid.Name = "fptxtuid";
            this.fptxtuid.Size = new System.Drawing.Size(140, 20);
            this.fptxtuid.TabIndex = 1;
            // 
            // fptxtans
            // 
            this.fptxtans.Location = new System.Drawing.Point(133, 134);
            this.fptxtans.Name = "fptxtans";
            this.fptxtans.Size = new System.Drawing.Size(140, 20);
            this.fptxtans.TabIndex = 4;
            // 
            // fpcomboque
            // 
            this.fpcomboque.FormattingEnabled = true;
            this.fpcomboque.Location = new System.Drawing.Point(133, 93);
            this.fpcomboque.Name = "fpcomboque";
            this.fpcomboque.Size = new System.Drawing.Size(140, 21);
            this.fpcomboque.TabIndex = 3;
            // 
            // btnsubmit
            // 
            this.btnsubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsubmit.Location = new System.Drawing.Point(42, 227);
            this.btnsubmit.Name = "btnsubmit";
            this.btnsubmit.Size = new System.Drawing.Size(75, 23);
            this.btnsubmit.TabIndex = 5;
            this.btnsubmit.Text = "Submit";
            this.btnsubmit.UseVisualStyleBackColor = true;
            this.btnsubmit.Click += new System.EventHandler(this.button1_Click);
            // 
            // btncancel
            // 
            this.btncancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncancel.Location = new System.Drawing.Point(182, 227);
            this.btncancel.Name = "btncancel";
            this.btncancel.Size = new System.Drawing.Size(75, 23);
            this.btncancel.TabIndex = 6;
            this.btncancel.Text = "Cancel";
            this.btncancel.UseVisualStyleBackColor = true;
            this.btncancel.Click += new System.EventHandler(this.btncancel_Click);
            // 
            // fplblemail
            // 
            this.fplblemail.AutoSize = true;
            this.fplblemail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fplblemail.Location = new System.Drawing.Point(20, 51);
            this.fplblemail.Name = "fplblemail";
            this.fplblemail.Size = new System.Drawing.Size(42, 16);
            this.fplblemail.TabIndex = 9;
            this.fplblemail.Text = "Email";
            // 
            // fptxtemail
            // 
            this.fptxtemail.Location = new System.Drawing.Point(133, 48);
            this.fptxtemail.Name = "fptxtemail";
            this.fptxtemail.Size = new System.Drawing.Size(140, 20);
            this.fptxtemail.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.fptxtemail);
            this.panel1.Controls.Add(this.fplblemail);
            this.panel1.Controls.Add(this.btncancel);
            this.panel1.Controls.Add(this.btnsubmit);
            this.panel1.Controls.Add(this.fpcomboque);
            this.panel1.Controls.Add(this.fptxtans);
            this.panel1.Controls.Add(this.fptxtuid);
            this.panel1.Controls.Add(this.fplblans);
            this.panel1.Controls.Add(this.fplblque);
            this.panel1.Controls.Add(this.fplbluid);
            this.panel1.Location = new System.Drawing.Point(241, 200);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(294, 311);
            this.panel1.TabIndex = 11;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Image = ((System.Drawing.Image)(resources.GetObject("label3.Image")));
            this.label3.Location = new System.Drawing.Point(34, 39);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(353, 25);
            this.label3.TabIndex = 36;
            this.label3.Text = "Passport Visa Processing Solutions";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::PassportSevaNew.Properties.Resources.header2;
            this.pictureBox1.Location = new System.Drawing.Point(-2, -3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(883, 112);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 35;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(249, 124);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(152, 24);
            this.label2.TabIndex = 56;
            this.label2.Text = "Forgot Password";
            // 
            // lineShape1
            // 
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 241;
            this.lineShape1.X2 = 880;
            this.lineShape1.Y1 = 158;
            this.lineShape1.Y2 = 158;
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(884, 612);
            this.shapeContainer1.TabIndex = 57;
            this.shapeContainer1.TabStop = false;
            // 
            // ForgotPassword
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(884, 612);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.shapeContainer1);
            this.Location = new System.Drawing.Point(30, 30);
            this.MaximumSize = new System.Drawing.Size(900, 650);
            this.Name = "ForgotPassword";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "ForgotPassword";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label fplbluid;
        private System.Windows.Forms.Label fplblque;
        private System.Windows.Forms.Label fplblans;
        private System.Windows.Forms.TextBox fptxtuid;
        private System.Windows.Forms.TextBox fptxtans;
        private System.Windows.Forms.ComboBox fpcomboque;
        private System.Windows.Forms.Button btnsubmit;
        private System.Windows.Forms.Button btncancel;
        private System.Windows.Forms.Label fplblemail;
        private System.Windows.Forms.TextBox fptxtemail;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
    }
}