﻿namespace PassportSevaNew
{
    partial class ReissuePassport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ReissuePassport));
            this.lblreissue = new System.Windows.Forms.Label();
            this.lbluserid = new System.Windows.Forms.Label();
            this.lblpassportid = new System.Windows.Forms.Label();
            this.lblcountry = new System.Windows.Forms.Label();
            this.lblstate = new System.Windows.Forms.Label();
            this.lblcity = new System.Windows.Forms.Label();
            this.lblpin = new System.Windows.Forms.Label();
            this.lbltypeofservice = new System.Windows.Forms.Label();
            this.lblbooklettype = new System.Windows.Forms.Label();
            this.lblissuedate = new System.Windows.Forms.Label();
            this.ddlreason = new System.Windows.Forms.ComboBox();
            this.txtuserid = new System.Windows.Forms.TextBox();
            this.txtpassportid = new System.Windows.Forms.TextBox();
            this.ddlcountry = new System.Windows.Forms.ComboBox();
            this.ddlstate = new System.Windows.Forms.ComboBox();
            this.ddlcity = new System.Windows.Forms.ComboBox();
            this.txtpin = new System.Windows.Forms.TextBox();
            this.rbtnnormal = new System.Windows.Forms.RadioButton();
            this.rbtntatkal = new System.Windows.Forms.RadioButton();
            this.rbtn30pages = new System.Windows.Forms.RadioButton();
            this.rbtn60pages = new System.Windows.Forms.RadioButton();
            this.btnsubmit = new System.Windows.Forms.Button();
            this.btncancel = new System.Windows.Forms.Button();
            this.lblerror = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.gptypeofservice = new System.Windows.Forms.GroupBox();
            this.grpboxbtype = new System.Windows.Forms.GroupBox();
            this.errpin = new System.Windows.Forms.Label();
            this.errissuedate = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtapply = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.hbtnchnfpass = new System.Windows.Forms.Button();
            this.hbtnrisspass = new System.Windows.Forms.Button();
            this.hbtnapplyvisa = new System.Windows.Forms.Button();
            this.hbtnvisacncl = new System.Windows.Forms.Button();
            this.hbtnapply = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.gptypeofservice.SuspendLayout();
            this.grpboxbtype.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblreissue
            // 
            this.lblreissue.AutoSize = true;
            this.lblreissue.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblreissue.Location = new System.Drawing.Point(12, 17);
            this.lblreissue.Name = "lblreissue";
            this.lblreissue.Size = new System.Drawing.Size(127, 16);
            this.lblreissue.TabIndex = 0;
            this.lblreissue.Text = "Reason for Reissue";
            // 
            // lbluserid
            // 
            this.lbluserid.AutoSize = true;
            this.lbluserid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbluserid.Location = new System.Drawing.Point(74, 60);
            this.lbluserid.Name = "lbluserid";
            this.lbluserid.Size = new System.Drawing.Size(53, 16);
            this.lbluserid.TabIndex = 1;
            this.lbluserid.Text = "User ID";
            // 
            // lblpassportid
            // 
            this.lblpassportid.AutoSize = true;
            this.lblpassportid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpassportid.Location = new System.Drawing.Point(46, 101);
            this.lblpassportid.Name = "lblpassportid";
            this.lblpassportid.Size = new System.Drawing.Size(78, 16);
            this.lblpassportid.TabIndex = 2;
            this.lblpassportid.Text = "Passport ID";
            // 
            // lblcountry
            // 
            this.lblcountry.AutoSize = true;
            this.lblcountry.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcountry.Location = new System.Drawing.Point(70, 148);
            this.lblcountry.Name = "lblcountry";
            this.lblcountry.Size = new System.Drawing.Size(53, 16);
            this.lblcountry.TabIndex = 3;
            this.lblcountry.Text = "Country";
            // 
            // lblstate
            // 
            this.lblstate.AutoSize = true;
            this.lblstate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblstate.Location = new System.Drawing.Point(77, 188);
            this.lblstate.Name = "lblstate";
            this.lblstate.Size = new System.Drawing.Size(39, 16);
            this.lblstate.TabIndex = 4;
            this.lblstate.Text = "State";
            // 
            // lblcity
            // 
            this.lblcity.AutoSize = true;
            this.lblcity.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcity.Location = new System.Drawing.Point(80, 228);
            this.lblcity.Name = "lblcity";
            this.lblcity.Size = new System.Drawing.Size(30, 16);
            this.lblcity.TabIndex = 5;
            this.lblcity.Text = "City";
            // 
            // lblpin
            // 
            this.lblpin.AutoSize = true;
            this.lblpin.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpin.Location = new System.Drawing.Point(79, 270);
            this.lblpin.Name = "lblpin";
            this.lblpin.Size = new System.Drawing.Size(27, 16);
            this.lblpin.TabIndex = 6;
            this.lblpin.Text = "Pin";
            // 
            // lbltypeofservice
            // 
            this.lbltypeofservice.AutoSize = true;
            this.lbltypeofservice.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltypeofservice.Location = new System.Drawing.Point(12, 320);
            this.lbltypeofservice.Name = "lbltypeofservice";
            this.lbltypeofservice.Size = new System.Drawing.Size(103, 16);
            this.lbltypeofservice.TabIndex = 7;
            this.lbltypeofservice.Text = "Type of Service";
            // 
            // lblbooklettype
            // 
            this.lblbooklettype.AutoSize = true;
            this.lblbooklettype.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbooklettype.Location = new System.Drawing.Point(25, 412);
            this.lblbooklettype.Name = "lblbooklettype";
            this.lblbooklettype.Size = new System.Drawing.Size(89, 16);
            this.lblbooklettype.TabIndex = 8;
            this.lblbooklettype.Text = "Booklet Type";
            // 
            // lblissuedate
            // 
            this.lblissuedate.AutoSize = true;
            this.lblissuedate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblissuedate.Location = new System.Drawing.Point(38, 364);
            this.lblissuedate.Name = "lblissuedate";
            this.lblissuedate.Size = new System.Drawing.Size(75, 16);
            this.lblissuedate.TabIndex = 9;
            this.lblissuedate.Text = "Apply Date";
            // 
            // ddlreason
            // 
            this.ddlreason.FormattingEnabled = true;
            this.ddlreason.Location = new System.Drawing.Point(164, 14);
            this.ddlreason.Name = "ddlreason";
            this.ddlreason.Size = new System.Drawing.Size(200, 24);
            this.ddlreason.TabIndex = 1;
            // 
            // txtuserid
            // 
            this.txtuserid.Enabled = false;
            this.txtuserid.Location = new System.Drawing.Point(164, 61);
            this.txtuserid.Name = "txtuserid";
            this.txtuserid.Size = new System.Drawing.Size(200, 22);
            this.txtuserid.TabIndex = 2;
            // 
            // txtpassportid
            // 
            this.txtpassportid.Location = new System.Drawing.Point(164, 101);
            this.txtpassportid.Name = "txtpassportid";
            this.txtpassportid.Size = new System.Drawing.Size(200, 22);
            this.txtpassportid.TabIndex = 3;
            // 
            // ddlcountry
            // 
            this.ddlcountry.FormattingEnabled = true;
            this.ddlcountry.Location = new System.Drawing.Point(164, 148);
            this.ddlcountry.Name = "ddlcountry";
            this.ddlcountry.Size = new System.Drawing.Size(200, 24);
            this.ddlcountry.TabIndex = 4;
            // 
            // ddlstate
            // 
            this.ddlstate.FormattingEnabled = true;
            this.ddlstate.Location = new System.Drawing.Point(164, 188);
            this.ddlstate.Name = "ddlstate";
            this.ddlstate.Size = new System.Drawing.Size(200, 24);
            this.ddlstate.TabIndex = 5;
            this.ddlstate.SelectedIndexChanged += new System.EventHandler(this.ddlstate_SelectedIndexChanged_1);
            // 
            // ddlcity
            // 
            this.ddlcity.FormattingEnabled = true;
            this.ddlcity.Location = new System.Drawing.Point(164, 228);
            this.ddlcity.Name = "ddlcity";
            this.ddlcity.Size = new System.Drawing.Size(200, 24);
            this.ddlcity.TabIndex = 6;
            // 
            // txtpin
            // 
            this.txtpin.Location = new System.Drawing.Point(164, 270);
            this.txtpin.MaxLength = 6;
            this.txtpin.Name = "txtpin";
            this.txtpin.Size = new System.Drawing.Size(200, 22);
            this.txtpin.TabIndex = 7;
            // 
            // rbtnnormal
            // 
            this.rbtnnormal.AutoSize = true;
            this.rbtnnormal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnnormal.Location = new System.Drawing.Point(15, 15);
            this.rbtnnormal.Name = "rbtnnormal";
            this.rbtnnormal.Size = new System.Drawing.Size(70, 20);
            this.rbtnnormal.TabIndex = 8;
            this.rbtnnormal.TabStop = true;
            this.rbtnnormal.Text = "Normal";
            this.rbtnnormal.UseVisualStyleBackColor = true;
            // 
            // rbtntatkal
            // 
            this.rbtntatkal.AutoSize = true;
            this.rbtntatkal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtntatkal.Location = new System.Drawing.Point(117, 15);
            this.rbtntatkal.Name = "rbtntatkal";
            this.rbtntatkal.Size = new System.Drawing.Size(64, 20);
            this.rbtntatkal.TabIndex = 9;
            this.rbtntatkal.TabStop = true;
            this.rbtntatkal.Text = "Tatkal";
            this.rbtntatkal.UseVisualStyleBackColor = true;
            // 
            // rbtn30pages
            // 
            this.rbtn30pages.AutoSize = true;
            this.rbtn30pages.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtn30pages.Location = new System.Drawing.Point(15, 17);
            this.rbtn30pages.Name = "rbtn30pages";
            this.rbtn30pages.Size = new System.Drawing.Size(83, 20);
            this.rbtn30pages.TabIndex = 11;
            this.rbtn30pages.TabStop = true;
            this.rbtn30pages.Text = "30 Pages";
            this.rbtn30pages.UseVisualStyleBackColor = true;
            // 
            // rbtn60pages
            // 
            this.rbtn60pages.AutoSize = true;
            this.rbtn60pages.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtn60pages.Location = new System.Drawing.Point(117, 17);
            this.rbtn60pages.Name = "rbtn60pages";
            this.rbtn60pages.Size = new System.Drawing.Size(83, 20);
            this.rbtn60pages.TabIndex = 12;
            this.rbtn60pages.TabStop = true;
            this.rbtn60pages.Text = "60 Pages";
            this.rbtn60pages.UseVisualStyleBackColor = true;
            // 
            // btnsubmit
            // 
            this.btnsubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsubmit.Location = new System.Drawing.Point(129, 521);
            this.btnsubmit.Name = "btnsubmit";
            this.btnsubmit.Size = new System.Drawing.Size(75, 23);
            this.btnsubmit.TabIndex = 13;
            this.btnsubmit.Text = "Submit";
            this.btnsubmit.UseVisualStyleBackColor = true;
            this.btnsubmit.Click += new System.EventHandler(this.btnsubmit_Click);
            // 
            // btncancel
            // 
            this.btncancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncancel.Location = new System.Drawing.Point(281, 521);
            this.btncancel.Name = "btncancel";
            this.btncancel.Size = new System.Drawing.Size(75, 23);
            this.btncancel.TabIndex = 14;
            this.btncancel.Text = "Cancel";
            this.btncancel.UseVisualStyleBackColor = true;
            this.btncancel.Click += new System.EventHandler(this.btncancel_Click);
            // 
            // lblerror
            // 
            this.lblerror.AutoSize = true;
            this.lblerror.Location = new System.Drawing.Point(38, 461);
            this.lblerror.Name = "lblerror";
            this.lblerror.Size = new System.Drawing.Size(0, 16);
            this.lblerror.TabIndex = 24;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(22, 386);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 16);
            this.label1.TabIndex = 25;
            // 
            // gptypeofservice
            // 
            this.gptypeofservice.Controls.Add(this.rbtnnormal);
            this.gptypeofservice.Controls.Add(this.rbtntatkal);
            this.gptypeofservice.Location = new System.Drawing.Point(164, 301);
            this.gptypeofservice.Name = "gptypeofservice";
            this.gptypeofservice.Size = new System.Drawing.Size(200, 39);
            this.gptypeofservice.TabIndex = 26;
            this.gptypeofservice.TabStop = false;
            // 
            // grpboxbtype
            // 
            this.grpboxbtype.Controls.Add(this.rbtn30pages);
            this.grpboxbtype.Controls.Add(this.rbtn60pages);
            this.grpboxbtype.Location = new System.Drawing.Point(174, 395);
            this.grpboxbtype.Name = "grpboxbtype";
            this.grpboxbtype.Size = new System.Drawing.Size(200, 45);
            this.grpboxbtype.TabIndex = 27;
            this.grpboxbtype.TabStop = false;
            // 
            // errpin
            // 
            this.errpin.AutoSize = true;
            this.errpin.Location = new System.Drawing.Point(370, 270);
            this.errpin.Name = "errpin";
            this.errpin.Size = new System.Drawing.Size(0, 16);
            this.errpin.TabIndex = 28;
            // 
            // errissuedate
            // 
            this.errissuedate.AutoSize = true;
            this.errissuedate.Location = new System.Drawing.Point(390, 363);
            this.errissuedate.Name = "errissuedate";
            this.errissuedate.Size = new System.Drawing.Size(0, 16);
            this.errissuedate.TabIndex = 29;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txtapply);
            this.panel1.Controls.Add(this.errissuedate);
            this.panel1.Controls.Add(this.errpin);
            this.panel1.Controls.Add(this.grpboxbtype);
            this.panel1.Controls.Add(this.gptypeofservice);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.lblerror);
            this.panel1.Controls.Add(this.btncancel);
            this.panel1.Controls.Add(this.btnsubmit);
            this.panel1.Controls.Add(this.txtpin);
            this.panel1.Controls.Add(this.ddlcity);
            this.panel1.Controls.Add(this.ddlstate);
            this.panel1.Controls.Add(this.ddlcountry);
            this.panel1.Controls.Add(this.txtpassportid);
            this.panel1.Controls.Add(this.txtuserid);
            this.panel1.Controls.Add(this.ddlreason);
            this.panel1.Controls.Add(this.lblissuedate);
            this.panel1.Controls.Add(this.lblbooklettype);
            this.panel1.Controls.Add(this.lbltypeofservice);
            this.panel1.Controls.Add(this.lblpin);
            this.panel1.Controls.Add(this.lblcity);
            this.panel1.Controls.Add(this.lblstate);
            this.panel1.Controls.Add(this.lblcountry);
            this.panel1.Controls.Add(this.lblpassportid);
            this.panel1.Controls.Add(this.lbluserid);
            this.panel1.Controls.Add(this.lblreissue);
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(248, 212);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(571, 613);
            this.panel1.TabIndex = 30;
            // 
            // txtapply
            // 
            this.txtapply.Enabled = false;
            this.txtapply.Location = new System.Drawing.Point(164, 369);
            this.txtapply.Name = "txtapply";
            this.txtapply.Size = new System.Drawing.Size(200, 22);
            this.txtapply.TabIndex = 30;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.hbtnchnfpass);
            this.panel3.Controls.Add(this.hbtnrisspass);
            this.panel3.Controls.Add(this.hbtnapplyvisa);
            this.panel3.Controls.Add(this.hbtnvisacncl);
            this.panel3.Controls.Add(this.hbtnapply);
            this.panel3.Location = new System.Drawing.Point(12, 212);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(219, 429);
            this.panel3.TabIndex = 54;
            // 
            // hbtnchnfpass
            // 
            this.hbtnchnfpass.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hbtnchnfpass.Location = new System.Drawing.Point(9, 293);
            this.hbtnchnfpass.Name = "hbtnchnfpass";
            this.hbtnchnfpass.Size = new System.Drawing.Size(140, 30);
            this.hbtnchnfpass.TabIndex = 5;
            this.hbtnchnfpass.Text = "Change Password";
            this.hbtnchnfpass.UseVisualStyleBackColor = true;
            this.hbtnchnfpass.Click += new System.EventHandler(this.hbtnchnfpass_Click);
            // 
            // hbtnrisspass
            // 
            this.hbtnrisspass.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hbtnrisspass.Location = new System.Drawing.Point(9, 93);
            this.hbtnrisspass.Name = "hbtnrisspass";
            this.hbtnrisspass.Size = new System.Drawing.Size(140, 30);
            this.hbtnrisspass.TabIndex = 4;
            this.hbtnrisspass.Text = "Reissue Passport";
            this.hbtnrisspass.UseVisualStyleBackColor = true;
            this.hbtnrisspass.Click += new System.EventHandler(this.hbtnrisspass_Click);
            // 
            // hbtnapplyvisa
            // 
            this.hbtnapplyvisa.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hbtnapplyvisa.Location = new System.Drawing.Point(9, 157);
            this.hbtnapplyvisa.Name = "hbtnapplyvisa";
            this.hbtnapplyvisa.Size = new System.Drawing.Size(140, 30);
            this.hbtnapplyvisa.TabIndex = 3;
            this.hbtnapplyvisa.Text = "Apply for Visa";
            this.hbtnapplyvisa.UseVisualStyleBackColor = true;
            this.hbtnapplyvisa.Click += new System.EventHandler(this.hbtnapplyvisa_Click);
            // 
            // hbtnvisacncl
            // 
            this.hbtnvisacncl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hbtnvisacncl.Location = new System.Drawing.Point(9, 224);
            this.hbtnvisacncl.Name = "hbtnvisacncl";
            this.hbtnvisacncl.Size = new System.Drawing.Size(140, 30);
            this.hbtnvisacncl.TabIndex = 2;
            this.hbtnvisacncl.Text = "Visa Cancellation";
            this.hbtnvisacncl.UseVisualStyleBackColor = true;
            this.hbtnvisacncl.Click += new System.EventHandler(this.hbtnvisacncl_Click);
            // 
            // hbtnapply
            // 
            this.hbtnapply.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hbtnapply.Location = new System.Drawing.Point(9, 36);
            this.hbtnapply.Name = "hbtnapply";
            this.hbtnapply.Size = new System.Drawing.Size(140, 30);
            this.hbtnapply.TabIndex = 1;
            this.hbtnapply.Text = "Apply for Passport";
            this.hbtnapply.UseVisualStyleBackColor = true;
            this.hbtnapply.Click += new System.EventHandler(this.hbtnapply_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(221, 148);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(155, 24);
            this.label2.TabIndex = 56;
            this.label2.Text = "Reissue Passport";
            // 
            // lineShape1
            // 
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 225;
            this.lineShape1.X2 = 864;
            this.lineShape1.Y1 = 187;
            this.lineShape1.Y2 = 187;
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(881, 825);
            this.shapeContainer1.TabIndex = 57;
            this.shapeContainer1.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Image = ((System.Drawing.Image)(resources.GetObject("label3.Image")));
            this.label3.Location = new System.Drawing.Point(34, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(353, 25);
            this.label3.TabIndex = 32;
            this.label3.Text = "Passport Visa Processing Solutions";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::PassportSevaNew.Properties.Resources.header2;
            this.pictureBox1.Location = new System.Drawing.Point(-2, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(883, 112);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 31;
            this.pictureBox1.TabStop = false;
            // 
            // ReissuePassport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(884, 612);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.shapeContainer1);
            this.Location = new System.Drawing.Point(30, 30);
            this.MaximumSize = new System.Drawing.Size(900, 650);
            this.Name = "ReissuePassport";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Reissue Passport";
            this.gptypeofservice.ResumeLayout(false);
            this.gptypeofservice.PerformLayout();
            this.grpboxbtype.ResumeLayout(false);
            this.grpboxbtype.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblreissue;
        private System.Windows.Forms.Label lbluserid;
        private System.Windows.Forms.Label lblpassportid;
        private System.Windows.Forms.Label lblcountry;
        private System.Windows.Forms.Label lblstate;
        private System.Windows.Forms.Label lblcity;
        private System.Windows.Forms.Label lblpin;
        private System.Windows.Forms.Label lbltypeofservice;
        private System.Windows.Forms.Label lblbooklettype;
        private System.Windows.Forms.Label lblissuedate;
        private System.Windows.Forms.ComboBox ddlreason;
        private System.Windows.Forms.TextBox txtuserid;
        private System.Windows.Forms.TextBox txtpassportid;
        private System.Windows.Forms.ComboBox ddlcountry;
        private System.Windows.Forms.ComboBox ddlstate;
        private System.Windows.Forms.ComboBox ddlcity;
        private System.Windows.Forms.TextBox txtpin;
        private System.Windows.Forms.RadioButton rbtnnormal;
        private System.Windows.Forms.RadioButton rbtntatkal;
        private System.Windows.Forms.RadioButton rbtn30pages;
        private System.Windows.Forms.RadioButton rbtn60pages;
        private System.Windows.Forms.Button btnsubmit;
        private System.Windows.Forms.Button btncancel;
        private System.Windows.Forms.Label lblerror;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox gptypeofservice;
        private System.Windows.Forms.GroupBox grpboxbtype;
        private System.Windows.Forms.Label errissuedate;
        private System.Windows.Forms.Label errpin;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button hbtnchnfpass;
        private System.Windows.Forms.Button hbtnrisspass;
        private System.Windows.Forms.Button hbtnapplyvisa;
        private System.Windows.Forms.Button hbtnvisacncl;
        private System.Windows.Forms.Button hbtnapply;
        private System.Windows.Forms.Label label2;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private System.Windows.Forms.TextBox txtapply;
    }
}

