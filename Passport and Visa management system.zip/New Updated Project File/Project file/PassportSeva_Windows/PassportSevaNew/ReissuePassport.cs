﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MainDllLibrary;
using System.Configuration;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace PassportSevaNew
{
    public partial class ReissuePassport : Form
    {
        public bool flag1 = false;
        public string userid = "";

      

        public ReissuePassport(string uid)
        {
            
            InitializeComponent();
            userid = uid;
            txtuserid.Text = uid;
            ddlcountry.Items.Add("India");

            GenerateFields generate = new GenerateFields();
            string s = ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString;

            generate.OpenConnection(s);
            DataSet ds = generate.GetStates();
            ddlstate.DataSource = ds.Tables[0];
            ddlstate.ValueMember = ds.Tables[0].Columns["sid"].ToString();
            ddlstate.DisplayMember = "sname";
            DataSet d1 = generate.GetCities("S_A001");
            ddlcity.DataSource = d1.Tables[0];
            ddlcity.ValueMember = d1.Tables["cities"].Columns[1].ToString();
            ddlstate.DisplayMember = "city";
            generate.CloseConnection();
            ddlreason.Items.Add("Damaged Passport");
            ddlreason.Items.Add("Change in existing personal particulars");

            ddlreason.Items.Add("Validity expired within 3 years/Due to expire");
            ddlreason.Items.Add("Lost Passport");
            ddlreason.Items.Add("Exhaustion of Pages ");
            ddlreason.Items.Add("Validity expired more than 3 years ago");

            txtapply.Text = DateTime.Today.ToString().Substring(0,9);

        }

        private void btnsubmit_Click(object sender, EventArgs e)
        {

            bool flag1 = true,flag2=true,flag3=true;

            //validation for required fields
            if (txtpassportid.Text == "" || txtpin.Text == "" || txtuserid.Text == "" || ddlcity.SelectedItem == null || ddlcountry.SelectedItem == null || ddlreason.SelectedItem == null || ddlstate.SelectedItem == null || !(rbtn30pages.Checked || rbtn60pages.Checked) || !(rbtnnormal.Checked || rbtntatkal.Checked))
            {
                flag1 = false;
            }
            else
                flag1 = true;

            ////validation for issue date
            //if (txtissuedate.Value < DateTime.Today)
            //{
            //    errissuedate.Text = "Please enter a valid date";
            //    errissuedate.ForeColor = System.Drawing.Color.Red;
            //    flag2 = false;
            //}
            //else
            //{
            //    errissuedate.Text = "";
            //    flag2 = true;
            //}

            //validation for pin
            Regex r1 = new Regex("^[0-9]{6}$");

            if (!(r1.IsMatch(txtpin.Text)))
            {
                errpin.Text = "Please enter correct pincode";
                errpin.ForeColor = System.Drawing.Color.Red;
                flag3 = false;
            }
            else
            {
                errpin.Text = "";
                flag3 = true;
            }

          

            if (flag1 == true && flag2==true && flag3==true)
            {
                bool flag = false;
                string pid, uid, reason;
                pid = txtpassportid.Text;
                uid = txtuserid.Text;
                reason = ddlreason.Text;
                string s = ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString;
                PassportConnect pc = new PassportConnect();
                pc.OpenConnection(s);

                Passport p = pc.GetPassportByPid(pid, uid);
                if (p.PID != null)
                {
                    flag = pc.PassportHistory(p, reason);

                    if (flag == true)
                    {
                        Passport newPassport = p;
                        newPassport.Pin = Convert.ToInt32(txtpin.Text);
                        newPassport.State = ddlstate.Text;
                        newPassport.Country = ddlcountry.Text;

                        if (rbtnnormal.Checked)
                        {
                            newPassport.TypeofService = rbtnnormal.Text;
                        }

                        else if (rbtntatkal.Checked)
                        {
                            newPassport.TypeofService = rbtntatkal.Text;
                        }

                       
                        newPassport.ApplyDate = DateTime.Today ;

                        if (rbtn30pages.Checked)
                        {
                            newPassport.BookletType = 30;
                        }

                        else if (rbtn60pages.Checked)
                        {
                            newPassport.BookletType = 60;
                        }

                        Passport newCredits = pc.InsertPassport(newPassport);

                        if (newCredits.PID != "")
                        {
                            bool updateFlag = pc.UpdatePassport(pid, uid);
                            if (updateFlag)
                            {
                                this.Hide();

                                Success success = new Success(newCredits.PID, newCredits.Amount, newCredits.ExpiryDate,newCredits.Uid);

                                success.Show();
                                this.Hide();

                            }
                            else
                            {
                                this.Hide();
                                Error error = new Error();
                                error.Show();
                            }
                        }
                        else
                        {
                            this.Hide();
                            Error error = new Error();
                            error.Show();

                        }


                    }

                    else
                    {
                        Error err = new Error();
                        err.Show();
                        this.Hide();
                    }

                }
                else
                {
                    lblerror.Text = "Passport does not exist";
                    lblerror.ForeColor = System.Drawing.Color.Red;
                    txtpassportid.Focus();
                }

                pc.CloseConnection();

            }
            else
                MessageBox.Show("Please enter all the required fields");
        }

     

       

        private void btncancel_Click(object sender, EventArgs e)
        {
            Home h = new Home();
            h.Show();
            this.Hide();

        }

        private void ddlstate_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            string id = ddlstate.SelectedValue.ToString();


            string s = ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString;
            GenerateFields generate = new GenerateFields();
            generate.OpenConnection(s);
            DataSet ds = generate.GetCities(id);
            ddlcity.DataSource = ds.Tables[0];
            ddlcity.DisplayMember = "city";
            generate.CloseConnection();
        }

      

       

        private void hbtnapply_Click(object sender, EventArgs e)
        {
            ApplyPassport ap = new ApplyPassport(userid);
            ap.Show();
            this.Hide();
        }

        private void hbtnrisspass_Click(object sender, EventArgs e)
        {
            ReissuePassport rp = new ReissuePassport(userid);
            rp.Show();
            this.Hide();
        }

        private void hbtnapplyvisa_Click(object sender, EventArgs e)
        {
            ApplyVisa av = new ApplyVisa(userid);
            av.Show();
            this.Hide();
        }

        private void hbtnvisacncl_Click(object sender, EventArgs e)
        {
            VisaCancellation vc = new VisaCancellation(userid);
            vc.Show();
            this.Hide();
        }

        private void hbtnchnfpass_Click(object sender, EventArgs e)
        {
            ChangePassword c = new ChangePassword(userid);
            c.Show();
            this.Hide();
        }

        
       
    }
}
