﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MainDllLibrary;
using System.Configuration;

namespace PassportSevaNew
{
    public partial class LoginUser : Form
    {

        public LoginUser()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            bool flag = true;
            //validations

            if (txtuserid.Text == "" || txtpassword.Text == "")
            {
                flag = false;
            }

            if (flag == true)
            {

                Credentials credits = new Credentials();
                credits.uid = txtuserid.Text;
                credits.password = txtpassword.Text;
                UserConnection ucon = new UserConnection();
                bool isValidUser = false;
                try
                {
                    string sql = ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString;

                    ucon.OpenConnection(sql);

                    isValidUser = ucon.ValidateUser(credits);
                    if (isValidUser)
                    {
                       
                        User u = new User();
                        u = ucon.GetUserById(credits.uid);

                        Home h = new Home(u.Fname, u.Lname, credits.uid, u.Dob);
                        h.Show();
                        this.Hide();
                      
                      

                    }
                    else
                    {
                        lblError.Text = "Please check your Userid or password";
                        lblError.ForeColor = System.Drawing.Color.Red;
                        
                    }

                   

                    ucon.CloseConnection();

                }
                catch (Exception)
                {

                    throw;
                }
            }
            else
            {
                MessageBox.Show("Please fill all the required fields");
            }
        }

    

        private void linklblfrgtpassword_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ForgotPassword fp = new ForgotPassword();
            fp.Show();
            this.Hide();
        }

        private void btnnewuser_Click(object sender, EventArgs e)
        {
            RegisterUser ru = new RegisterUser();
            ru.Show();
            this.Hide();
        }
    }
}
