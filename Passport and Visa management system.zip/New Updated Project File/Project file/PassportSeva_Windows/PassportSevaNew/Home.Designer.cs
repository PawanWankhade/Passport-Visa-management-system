﻿namespace PassportSevaNew
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            this.label1 = new System.Windows.Forms.Label();
            this.hbtnlogout = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.panel3 = new System.Windows.Forms.Panel();
            this.hbtnchnfpass = new System.Windows.Forms.Button();
            this.hbtnrisspass = new System.Windows.Forms.Button();
            this.hbtnapplyvisa = new System.Windows.Forms.Button();
            this.hbtnvisacncl = new System.Windows.Forms.Button();
            this.hbtnapply = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.lblHeading = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(499, 116);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 15);
            this.label1.TabIndex = 0;
            // 
            // hbtnlogout
            // 
            this.hbtnlogout.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hbtnlogout.Location = new System.Drawing.Point(661, 119);
            this.hbtnlogout.Name = "hbtnlogout";
            this.hbtnlogout.Size = new System.Drawing.Size(75, 23);
            this.hbtnlogout.TabIndex = 6;
            this.hbtnlogout.Text = "Logout";
            this.hbtnlogout.UseVisualStyleBackColor = true;
            this.hbtnlogout.Click += new System.EventHandler(this.hbtnlogout_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Image = ((System.Drawing.Image)(resources.GetObject("label3.Image")));
            this.label3.Location = new System.Drawing.Point(36, 43);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(353, 25);
            this.label3.TabIndex = 36;
            this.label3.Text = "Passport Visa Processing Solutions";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::PassportSevaNew.Properties.Resources.header2;
            this.pictureBox1.Location = new System.Drawing.Point(0, 1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(883, 112);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 35;
            this.pictureBox1.TabStop = false;
            // 
            // lineShape1
            // 
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 193;
            this.lineShape1.X2 = 735;
            this.lineShape1.Y1 = 194;
            this.lineShape1.Y2 = 194;
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(883, 537);
            this.shapeContainer1.TabIndex = 37;
            this.shapeContainer1.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.hbtnchnfpass);
            this.panel3.Controls.Add(this.hbtnrisspass);
            this.panel3.Controls.Add(this.hbtnapplyvisa);
            this.panel3.Controls.Add(this.hbtnvisacncl);
            this.panel3.Controls.Add(this.hbtnapply);
            this.panel3.Location = new System.Drawing.Point(0, 201);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(163, 336);
            this.panel3.TabIndex = 55;
            // 
            // hbtnchnfpass
            // 
            this.hbtnchnfpass.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hbtnchnfpass.Location = new System.Drawing.Point(12, 272);
            this.hbtnchnfpass.Name = "hbtnchnfpass";
            this.hbtnchnfpass.Size = new System.Drawing.Size(140, 30);
            this.hbtnchnfpass.TabIndex = 5;
            this.hbtnchnfpass.Text = "Change Password";
            this.hbtnchnfpass.UseVisualStyleBackColor = true;
            this.hbtnchnfpass.Click += new System.EventHandler(this.hbtnchnfpass_Click_1);
            // 
            // hbtnrisspass
            // 
            this.hbtnrisspass.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hbtnrisspass.Location = new System.Drawing.Point(12, 72);
            this.hbtnrisspass.Name = "hbtnrisspass";
            this.hbtnrisspass.Size = new System.Drawing.Size(140, 30);
            this.hbtnrisspass.TabIndex = 4;
            this.hbtnrisspass.Text = "Reissue Passport";
            this.hbtnrisspass.UseVisualStyleBackColor = true;
            this.hbtnrisspass.Click += new System.EventHandler(this.hbtnrisspass_Click_1);
            // 
            // hbtnapplyvisa
            // 
            this.hbtnapplyvisa.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hbtnapplyvisa.Location = new System.Drawing.Point(12, 136);
            this.hbtnapplyvisa.Name = "hbtnapplyvisa";
            this.hbtnapplyvisa.Size = new System.Drawing.Size(140, 30);
            this.hbtnapplyvisa.TabIndex = 3;
            this.hbtnapplyvisa.Text = "Apply for Visa";
            this.hbtnapplyvisa.UseVisualStyleBackColor = true;
            this.hbtnapplyvisa.Click += new System.EventHandler(this.hbtnapplyvisa_Click_1);
            // 
            // hbtnvisacncl
            // 
            this.hbtnvisacncl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hbtnvisacncl.Location = new System.Drawing.Point(12, 203);
            this.hbtnvisacncl.Name = "hbtnvisacncl";
            this.hbtnvisacncl.Size = new System.Drawing.Size(140, 30);
            this.hbtnvisacncl.TabIndex = 2;
            this.hbtnvisacncl.Text = "Visa Cancellation";
            this.hbtnvisacncl.UseVisualStyleBackColor = true;
            this.hbtnvisacncl.Click += new System.EventHandler(this.hbtnvisacncl_Click);
            // 
            // hbtnapply
            // 
            this.hbtnapply.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hbtnapply.Location = new System.Drawing.Point(12, 15);
            this.hbtnapply.Name = "hbtnapply";
            this.hbtnapply.Size = new System.Drawing.Size(140, 30);
            this.hbtnapply.TabIndex = 1;
            this.hbtnapply.Text = "Apply for Passport";
            this.hbtnapply.UseVisualStyleBackColor = true;
            this.hbtnapply.Click += new System.EventHandler(this.hbtnapply_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(238, 216);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(457, 80);
            this.label2.TabIndex = 56;
            this.label2.Text = resources.GetString("label2.Text");
            // 
            // lblHeading
            // 
            this.lblHeading.AutoSize = true;
            this.lblHeading.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeading.Location = new System.Drawing.Point(189, 160);
            this.lblHeading.Name = "lblHeading";
            this.lblHeading.Size = new System.Drawing.Size(381, 20);
            this.lblHeading.TabIndex = 57;
            this.lblHeading.Text = "Welcome to Passport and Visa Management System";
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(820, 514);
            this.Controls.Add(this.lblHeading);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.hbtnlogout);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.shapeContainer1);
            this.Location = new System.Drawing.Point(30, 30);
            this.MaximumSize = new System.Drawing.Size(900, 650);
            this.Name = "Home";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = " ";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button hbtnlogout;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button hbtnchnfpass;
        private System.Windows.Forms.Button hbtnrisspass;
        private System.Windows.Forms.Button hbtnapplyvisa;
        private System.Windows.Forms.Button hbtnvisacncl;
        private System.Windows.Forms.Button hbtnapply;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblHeading;

    }
}