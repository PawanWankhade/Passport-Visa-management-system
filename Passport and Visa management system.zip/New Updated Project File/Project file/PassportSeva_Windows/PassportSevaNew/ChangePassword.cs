﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MainDllLibrary;
using System.Configuration;

namespace PassportSevaNew
{
    public partial class ChangePassword : Form
    {
        string uid;
        public ChangePassword()
        {
            InitializeComponent();

        }

        public ChangePassword(string userid)
        {
            InitializeComponent();
            uid = userid;

        }

      

        private void cpbtnsubmit_Click(object sender, EventArgs e)
        {
            // code for validation
            bool flag1 = true;

            if (cptxtconfirmpass.Text == null || cptxtnewpass.Text == null || cptxtoldpass.Text == null)
            {
                flag1 = false;
            }

            if (flag1 == true)
            {

                if (cptxtnewpass.Text == cptxtconfirmpass.Text)
                {
                    Credentials c = new Credentials();

                    c.uid = uid;
                    c.password = cptxtoldpass.Text;
                    bool flag = true;
                    bool changePasswordFlag = false;
                    UserConnection ucon = new UserConnection();
                    ucon.OpenConnection(ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString);

                    flag = ucon.ValidateUser(c);
                    if (flag)
                    {
                        c.password = cptxtnewpass.Text;
                        changePasswordFlag = ucon.ChangePassword(c);
                        if (changePasswordFlag)
                        {
                            Success s = new Success();
                            s.Show();
                            this.Hide();
                        }
                        else
                        {
                            Error err = new Error();
                            err.Show();
                            this.Hide();
                        }

                    }
                    else
                    {
                        lblError.Text = "Please check old password";
                        lblError.ForeColor = System.Drawing.Color.Red;
                        cptxtoldpass.Focus();
                    }


                    ucon.CloseConnection();
                }
                else
                {
                    lblError.Text = "Password mismatch";
                }
            }
            else
                MessageBox.Show("Please enter all the required fields");
        }

        

        private void cpbtncancel_Click(object sender, EventArgs e)
        {
            Home h = new Home();
            h.Show();
            this.Hide();
        }

        private void hbtnapply_Click(object sender, EventArgs e)
        {
            ApplyPassport ap = new ApplyPassport(uid);
            ap.Show();
            this.Hide();
        }

        private void hbtnrisspass_Click(object sender, EventArgs e)
        {
            ReissuePassport rp = new ReissuePassport(uid);
            rp.Show();
            this.Hide();
        }

        private void hbtnapplyvisa_Click(object sender, EventArgs e)
        {
            ApplyVisa av = new ApplyVisa(uid);
            av.Show();
            this.Hide();
        }

        private void hbtnvisacncl_Click(object sender, EventArgs e)
        {
            VisaCancellation vc = new VisaCancellation(uid);
            vc.Show();
            this.Hide();
        }

        private void hbtnchnfpass_Click(object sender, EventArgs e)
        {
            ChangePassword c = new ChangePassword(uid);
            c.Show();
            this.Hide();
        }

       
    }
}
