﻿namespace PassportSevaNew
{
    partial class ApplyPassport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ApplyPassport));
            this.panel2 = new System.Windows.Forms.Panel();
            this.hbtnchnfpass = new System.Windows.Forms.Button();
            this.hbtnrisspass = new System.Windows.Forms.Button();
            this.hbtnapplyvisa = new System.Windows.Forms.Button();
            this.hbtnvisacncl = new System.Windows.Forms.Button();
            this.hbtnapply = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.errapplydate = new System.Windows.Forms.Label();
            this.errlname = new System.Windows.Forms.Label();
            this.errpin = new System.Windows.Forms.Label();
            this.errdob = new System.Windows.Forms.Label();
            this.errfname = new System.Windows.Forms.Label();
            this.grpboxbooklettype = new System.Windows.Forms.GroupBox();
            this.rbtn30pages = new System.Windows.Forms.RadioButton();
            this.rbtn60pages = new System.Windows.Forms.RadioButton();
            this.button1 = new System.Windows.Forms.Button();
            this.grpboxtypeofservice = new System.Windows.Forms.GroupBox();
            this.rbtnnormal = new System.Windows.Forms.RadioButton();
            this.rbtntatkal = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbtnmale = new System.Windows.Forms.RadioButton();
            this.rbtnfemale = new System.Windows.Forms.RadioButton();
            this.txtapplydate = new System.Windows.Forms.DateTimePicker();
            this.ddlqualification = new System.Windows.Forms.ComboBox();
            this.txtidentitynumber = new System.Windows.Forms.TextBox();
            this.ddlidentity = new System.Windows.Forms.ComboBox();
            this.ddlmaritalstatus = new System.Windows.Forms.ComboBox();
            this.txtpin = new System.Windows.Forms.TextBox();
            this.ddlcity = new System.Windows.Forms.ComboBox();
            this.ddlstate = new System.Windows.Forms.ComboBox();
            this.ddlcountry = new System.Windows.Forms.ComboBox();
            this.txtdateofbirth = new System.Windows.Forms.DateTimePicker();
            this.txtlastname = new System.Windows.Forms.TextBox();
            this.txtfirstname = new System.Windows.Forms.TextBox();
            this.btncancel = new System.Windows.Forms.Button();
            this.btnsubmit = new System.Windows.Forms.Button();
            this.lblbooklettype = new System.Windows.Forms.Label();
            this.lblapplydate = new System.Windows.Forms.Label();
            this.lbltypeofservice = new System.Windows.Forms.Label();
            this.lblqualification = new System.Windows.Forms.Label();
            this.lblidentitynumber = new System.Windows.Forms.Label();
            this.lblidentity = new System.Windows.Forms.Label();
            this.lblmaritalstatus = new System.Windows.Forms.Label();
            this.lblgender = new System.Windows.Forms.Label();
            this.lblpin = new System.Windows.Forms.Label();
            this.lblstate = new System.Windows.Forms.Label();
            this.lblcity = new System.Windows.Forms.Label();
            this.lblcountry = new System.Windows.Forms.Label();
            this.lbldateofbirth = new System.Windows.Forms.Label();
            this.lbllastname = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblfirstname = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.grpboxbooklettype.SuspendLayout();
            this.grpboxtypeofservice.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.hbtnchnfpass);
            this.panel2.Controls.Add(this.hbtnrisspass);
            this.panel2.Controls.Add(this.hbtnapplyvisa);
            this.panel2.Controls.Add(this.hbtnvisacncl);
            this.panel2.Controls.Add(this.hbtnapply);
            this.panel2.Location = new System.Drawing.Point(12, 195);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(210, 429);
            this.panel2.TabIndex = 52;
            // 
            // hbtnchnfpass
            // 
            this.hbtnchnfpass.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hbtnchnfpass.Location = new System.Drawing.Point(9, 277);
            this.hbtnchnfpass.Name = "hbtnchnfpass";
            this.hbtnchnfpass.Size = new System.Drawing.Size(140, 30);
            this.hbtnchnfpass.TabIndex = 5;
            this.hbtnchnfpass.Text = "Change Password";
            this.hbtnchnfpass.UseVisualStyleBackColor = true;
            this.hbtnchnfpass.Click += new System.EventHandler(this.hbtnchnfpass_Click);
            // 
            // hbtnrisspass
            // 
            this.hbtnrisspass.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hbtnrisspass.Location = new System.Drawing.Point(9, 77);
            this.hbtnrisspass.Name = "hbtnrisspass";
            this.hbtnrisspass.Size = new System.Drawing.Size(140, 30);
            this.hbtnrisspass.TabIndex = 4;
            this.hbtnrisspass.Text = "Reissue Passport";
            this.hbtnrisspass.UseVisualStyleBackColor = true;
            this.hbtnrisspass.Click += new System.EventHandler(this.hbtnrisspass_Click);
            // 
            // hbtnapplyvisa
            // 
            this.hbtnapplyvisa.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hbtnapplyvisa.Location = new System.Drawing.Point(9, 141);
            this.hbtnapplyvisa.Name = "hbtnapplyvisa";
            this.hbtnapplyvisa.Size = new System.Drawing.Size(140, 30);
            this.hbtnapplyvisa.TabIndex = 3;
            this.hbtnapplyvisa.Text = "Apply for Visa";
            this.hbtnapplyvisa.UseVisualStyleBackColor = true;
            this.hbtnapplyvisa.Click += new System.EventHandler(this.hbtnapplyvisa_Click);
            // 
            // hbtnvisacncl
            // 
            this.hbtnvisacncl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hbtnvisacncl.Location = new System.Drawing.Point(9, 208);
            this.hbtnvisacncl.Name = "hbtnvisacncl";
            this.hbtnvisacncl.Size = new System.Drawing.Size(140, 30);
            this.hbtnvisacncl.TabIndex = 2;
            this.hbtnvisacncl.Text = "Visa Cancellation";
            this.hbtnvisacncl.UseVisualStyleBackColor = true;
            this.hbtnvisacncl.Click += new System.EventHandler(this.hbtnvisacncl_Click);
            // 
            // hbtnapply
            // 
            this.hbtnapply.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hbtnapply.Location = new System.Drawing.Point(9, 20);
            this.hbtnapply.Name = "hbtnapply";
            this.hbtnapply.Size = new System.Drawing.Size(140, 30);
            this.hbtnapply.TabIndex = 1;
            this.hbtnapply.Text = "Apply for Passport";
            this.hbtnapply.UseVisualStyleBackColor = true;
            this.hbtnapply.Click += new System.EventHandler(this.hbtnapply_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(220, 133);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(161, 24);
            this.label2.TabIndex = 56;
            this.label2.Text = "Apply for Passport";
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(867, 739);
            this.shapeContainer1.TabIndex = 57;
            this.shapeContainer1.TabStop = false;
            // 
            // lineShape1
            // 
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 201;
            this.lineShape1.X2 = 840;
            this.lineShape1.Y1 = 171;
            this.lineShape1.Y2 = 171;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Image = ((System.Drawing.Image)(resources.GetObject("label3.Image")));
            this.label3.Location = new System.Drawing.Point(-1, -79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(353, 25);
            this.label3.TabIndex = 50;
            this.label3.Text = "Passport Visa Processing Solutions";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::PassportSevaNew.Properties.Resources.header2;
            this.pictureBox1.Location = new System.Drawing.Point(-16, -137);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(883, 112);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 49;
            this.pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.radioButton2);
            this.panel1.Controls.Add(this.radioButton1);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.errapplydate);
            this.panel1.Controls.Add(this.errlname);
            this.panel1.Controls.Add(this.errpin);
            this.panel1.Controls.Add(this.errdob);
            this.panel1.Controls.Add(this.errfname);
            this.panel1.Controls.Add(this.grpboxbooklettype);
            this.panel1.Controls.Add(this.grpboxtypeofservice);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.txtapplydate);
            this.panel1.Controls.Add(this.ddlqualification);
            this.panel1.Controls.Add(this.txtidentitynumber);
            this.panel1.Controls.Add(this.ddlidentity);
            this.panel1.Controls.Add(this.ddlmaritalstatus);
            this.panel1.Controls.Add(this.txtpin);
            this.panel1.Controls.Add(this.ddlcity);
            this.panel1.Controls.Add(this.ddlstate);
            this.panel1.Controls.Add(this.ddlcountry);
            this.panel1.Controls.Add(this.txtdateofbirth);
            this.panel1.Controls.Add(this.txtlastname);
            this.panel1.Controls.Add(this.txtfirstname);
            this.panel1.Controls.Add(this.btncancel);
            this.panel1.Controls.Add(this.btnsubmit);
            this.panel1.Controls.Add(this.lblbooklettype);
            this.panel1.Controls.Add(this.lblapplydate);
            this.panel1.Controls.Add(this.lbltypeofservice);
            this.panel1.Controls.Add(this.lblqualification);
            this.panel1.Controls.Add(this.lblidentitynumber);
            this.panel1.Controls.Add(this.lblidentity);
            this.panel1.Controls.Add(this.lblmaritalstatus);
            this.panel1.Controls.Add(this.lblgender);
            this.panel1.Controls.Add(this.lblpin);
            this.panel1.Controls.Add(this.lblstate);
            this.panel1.Controls.Add(this.lblcity);
            this.panel1.Controls.Add(this.lblcountry);
            this.panel1.Controls.Add(this.lbldateofbirth);
            this.panel1.Controls.Add(this.lbllastname);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.lblfirstname);
            this.panel1.Location = new System.Drawing.Point(228, 195);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(613, 544);
            this.panel1.TabIndex = 58;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton2.Location = new System.Drawing.Point(252, 6);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(44, 20);
            this.radioButton2.TabIndex = 47;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "No";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton1.Location = new System.Drawing.Point(161, 6);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(50, 20);
            this.radioButton1.TabIndex = 46;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Yes";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(17, 10);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(136, 16);
            this.label4.TabIndex = 45;
            this.label4.Text = "Applying for yourself?";
            // 
            // errapplydate
            // 
            this.errapplydate.AutoSize = true;
            this.errapplydate.Location = new System.Drawing.Point(368, 442);
            this.errapplydate.Name = "errapplydate";
            this.errapplydate.Size = new System.Drawing.Size(0, 13);
            this.errapplydate.TabIndex = 44;
            // 
            // errlname
            // 
            this.errlname.AutoSize = true;
            this.errlname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.errlname.Location = new System.Drawing.Point(368, 61);
            this.errlname.Name = "errlname";
            this.errlname.Size = new System.Drawing.Size(0, 16);
            this.errlname.TabIndex = 42;
            // 
            // errpin
            // 
            this.errpin.AutoSize = true;
            this.errpin.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.errpin.Location = new System.Drawing.Point(361, 230);
            this.errpin.Name = "errpin";
            this.errpin.Size = new System.Drawing.Size(0, 16);
            this.errpin.TabIndex = 41;
            // 
            // errdob
            // 
            this.errdob.AutoSize = true;
            this.errdob.Location = new System.Drawing.Point(368, 92);
            this.errdob.Name = "errdob";
            this.errdob.Size = new System.Drawing.Size(0, 13);
            this.errdob.TabIndex = 40;
            this.errdob.Click += new System.EventHandler(this.label5_Click);
            // 
            // errfname
            // 
            this.errfname.AutoSize = true;
            this.errfname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.errfname.Location = new System.Drawing.Point(361, 38);
            this.errfname.Name = "errfname";
            this.errfname.Size = new System.Drawing.Size(0, 16);
            this.errfname.TabIndex = 39;
            // 
            // grpboxbooklettype
            // 
            this.grpboxbooklettype.Controls.Add(this.rbtn30pages);
            this.grpboxbooklettype.Controls.Add(this.rbtn60pages);
            this.grpboxbooklettype.Controls.Add(this.button1);
            this.grpboxbooklettype.Location = new System.Drawing.Point(161, 470);
            this.grpboxbooklettype.Name = "grpboxbooklettype";
            this.grpboxbooklettype.Size = new System.Drawing.Size(200, 35);
            this.grpboxbooklettype.TabIndex = 38;
            this.grpboxbooklettype.TabStop = false;
            this.grpboxbooklettype.Enter += new System.EventHandler(this.grpboxbooklettype_Enter);
            // 
            // rbtn30pages
            // 
            this.rbtn30pages.AutoSize = true;
            this.rbtn30pages.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtn30pages.Location = new System.Drawing.Point(6, 13);
            this.rbtn30pages.Name = "rbtn30pages";
            this.rbtn30pages.Size = new System.Drawing.Size(83, 20);
            this.rbtn30pages.TabIndex = 17;
            this.rbtn30pages.TabStop = true;
            this.rbtn30pages.Text = "30 Pages";
            this.rbtn30pages.UseVisualStyleBackColor = true;
            // 
            // rbtn60pages
            // 
            this.rbtn60pages.AutoSize = true;
            this.rbtn60pages.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtn60pages.Location = new System.Drawing.Point(111, 13);
            this.rbtn60pages.Name = "rbtn60pages";
            this.rbtn60pages.Size = new System.Drawing.Size(83, 20);
            this.rbtn60pages.TabIndex = 18;
            this.rbtn60pages.TabStop = true;
            this.rbtn60pages.Text = "60 Pages";
            this.rbtn60pages.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(173, 84);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 17;
            this.button1.Text = "Cancel";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.btncancel_Click_1);
            // 
            // grpboxtypeofservice
            // 
            this.grpboxtypeofservice.Controls.Add(this.rbtnnormal);
            this.grpboxtypeofservice.Controls.Add(this.rbtntatkal);
            this.grpboxtypeofservice.Location = new System.Drawing.Point(155, 395);
            this.grpboxtypeofservice.Name = "grpboxtypeofservice";
            this.grpboxtypeofservice.Size = new System.Drawing.Size(200, 41);
            this.grpboxtypeofservice.TabIndex = 37;
            this.grpboxtypeofservice.TabStop = false;
            // 
            // rbtnnormal
            // 
            this.rbtnnormal.AutoSize = true;
            this.rbtnnormal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnnormal.Location = new System.Drawing.Point(14, 18);
            this.rbtnnormal.Name = "rbtnnormal";
            this.rbtnnormal.Size = new System.Drawing.Size(70, 20);
            this.rbtnnormal.TabIndex = 14;
            this.rbtnnormal.TabStop = true;
            this.rbtnnormal.Text = "Normal";
            this.rbtnnormal.UseVisualStyleBackColor = true;
            // 
            // rbtntatkal
            // 
            this.rbtntatkal.AutoSize = true;
            this.rbtntatkal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtntatkal.Location = new System.Drawing.Point(90, 19);
            this.rbtntatkal.Name = "rbtntatkal";
            this.rbtntatkal.Size = new System.Drawing.Size(64, 20);
            this.rbtntatkal.TabIndex = 15;
            this.rbtntatkal.TabStop = true;
            this.rbtntatkal.Text = "Tatkal";
            this.rbtntatkal.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbtnmale);
            this.groupBox1.Controls.Add(this.rbtnfemale);
            this.groupBox1.Location = new System.Drawing.Point(155, 245);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(160, 43);
            this.groupBox1.TabIndex = 36;
            this.groupBox1.TabStop = false;
            // 
            // rbtnmale
            // 
            this.rbtnmale.AutoSize = true;
            this.rbtnmale.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnmale.Location = new System.Drawing.Point(6, 16);
            this.rbtnmale.Name = "rbtnmale";
            this.rbtnmale.Size = new System.Drawing.Size(56, 20);
            this.rbtnmale.TabIndex = 8;
            this.rbtnmale.TabStop = true;
            this.rbtnmale.Text = "Male";
            this.rbtnmale.UseVisualStyleBackColor = true;
            // 
            // rbtnfemale
            // 
            this.rbtnfemale.AutoSize = true;
            this.rbtnfemale.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnfemale.Location = new System.Drawing.Point(82, 16);
            this.rbtnfemale.Name = "rbtnfemale";
            this.rbtnfemale.Size = new System.Drawing.Size(72, 20);
            this.rbtnfemale.TabIndex = 9;
            this.rbtnfemale.TabStop = true;
            this.rbtnfemale.Text = "Female";
            this.rbtnfemale.UseVisualStyleBackColor = true;
            // 
            // txtapplydate
            // 
            this.txtapplydate.Enabled = false;
            this.txtapplydate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtapplydate.Location = new System.Drawing.Point(154, 442);
            this.txtapplydate.Name = "txtapplydate";
            this.txtapplydate.Size = new System.Drawing.Size(200, 22);
            this.txtapplydate.TabIndex = 16;
            // 
            // ddlqualification
            // 
            this.ddlqualification.FormattingEnabled = true;
            this.ddlqualification.Location = new System.Drawing.Point(155, 374);
            this.ddlqualification.Name = "ddlqualification";
            this.ddlqualification.Size = new System.Drawing.Size(199, 21);
            this.ddlqualification.TabIndex = 13;
            // 
            // txtidentitynumber
            // 
            this.txtidentitynumber.Location = new System.Drawing.Point(155, 348);
            this.txtidentitynumber.Name = "txtidentitynumber";
            this.txtidentitynumber.Size = new System.Drawing.Size(199, 20);
            this.txtidentitynumber.TabIndex = 12;
            // 
            // ddlidentity
            // 
            this.ddlidentity.FormattingEnabled = true;
            this.ddlidentity.Location = new System.Drawing.Point(155, 321);
            this.ddlidentity.Name = "ddlidentity";
            this.ddlidentity.Size = new System.Drawing.Size(199, 21);
            this.ddlidentity.TabIndex = 11;
            // 
            // ddlmaritalstatus
            // 
            this.ddlmaritalstatus.FormattingEnabled = true;
            this.ddlmaritalstatus.Location = new System.Drawing.Point(155, 294);
            this.ddlmaritalstatus.Name = "ddlmaritalstatus";
            this.ddlmaritalstatus.Size = new System.Drawing.Size(199, 21);
            this.ddlmaritalstatus.TabIndex = 10;
            // 
            // txtpin
            // 
            this.txtpin.Location = new System.Drawing.Point(154, 223);
            this.txtpin.MaxLength = 6;
            this.txtpin.Name = "txtpin";
            this.txtpin.Size = new System.Drawing.Size(199, 20);
            this.txtpin.TabIndex = 7;
            // 
            // ddlcity
            // 
            this.ddlcity.FormattingEnabled = true;
            this.ddlcity.Location = new System.Drawing.Point(155, 189);
            this.ddlcity.Name = "ddlcity";
            this.ddlcity.Size = new System.Drawing.Size(199, 21);
            this.ddlcity.TabIndex = 6;
            // 
            // ddlstate
            // 
            this.ddlstate.FormattingEnabled = true;
            this.ddlstate.Location = new System.Drawing.Point(155, 158);
            this.ddlstate.Name = "ddlstate";
            this.ddlstate.Size = new System.Drawing.Size(199, 21);
            this.ddlstate.TabIndex = 5;
            this.ddlstate.SelectedIndexChanged += new System.EventHandler(this.ddlstate_SelectedIndexChanged_1);
            // 
            // ddlcountry
            // 
            this.ddlcountry.FormattingEnabled = true;
            this.ddlcountry.Location = new System.Drawing.Point(155, 125);
            this.ddlcountry.Name = "ddlcountry";
            this.ddlcountry.Size = new System.Drawing.Size(199, 21);
            this.ddlcountry.TabIndex = 4;
            // 
            // txtdateofbirth
            // 
            this.txtdateofbirth.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdateofbirth.Location = new System.Drawing.Point(155, 92);
            this.txtdateofbirth.Name = "txtdateofbirth";
            this.txtdateofbirth.Size = new System.Drawing.Size(200, 22);
            this.txtdateofbirth.TabIndex = 3;
            // 
            // txtlastname
            // 
            this.txtlastname.Location = new System.Drawing.Point(155, 58);
            this.txtlastname.MaxLength = 20;
            this.txtlastname.Name = "txtlastname";
            this.txtlastname.Size = new System.Drawing.Size(199, 20);
            this.txtlastname.TabIndex = 2;
            // 
            // txtfirstname
            // 
            this.txtfirstname.Location = new System.Drawing.Point(155, 34);
            this.txtfirstname.MaxLength = 30;
            this.txtfirstname.Name = "txtfirstname";
            this.txtfirstname.Size = new System.Drawing.Size(199, 20);
            this.txtfirstname.TabIndex = 1;
            // 
            // btncancel
            // 
            this.btncancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncancel.Location = new System.Drawing.Point(286, 511);
            this.btncancel.Name = "btncancel";
            this.btncancel.Size = new System.Drawing.Size(75, 23);
            this.btncancel.TabIndex = 20;
            this.btncancel.Text = "Cancel";
            this.btncancel.UseVisualStyleBackColor = true;
            this.btncancel.Click += new System.EventHandler(this.btncancel_Click_1);
            // 
            // btnsubmit
            // 
            this.btnsubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsubmit.Location = new System.Drawing.Point(161, 511);
            this.btnsubmit.Name = "btnsubmit";
            this.btnsubmit.Size = new System.Drawing.Size(75, 23);
            this.btnsubmit.TabIndex = 19;
            this.btnsubmit.Text = "Submit";
            this.btnsubmit.UseVisualStyleBackColor = true;
            this.btnsubmit.Click += new System.EventHandler(this.btnsubmit_Click_1);
            // 
            // lblbooklettype
            // 
            this.lblbooklettype.AutoSize = true;
            this.lblbooklettype.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbooklettype.Location = new System.Drawing.Point(18, 483);
            this.lblbooklettype.Name = "lblbooklettype";
            this.lblbooklettype.Size = new System.Drawing.Size(89, 16);
            this.lblbooklettype.TabIndex = 15;
            this.lblbooklettype.Text = "Booklet Type";
            // 
            // lblapplydate
            // 
            this.lblapplydate.AutoSize = true;
            this.lblapplydate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblapplydate.Location = new System.Drawing.Point(23, 447);
            this.lblapplydate.Name = "lblapplydate";
            this.lblapplydate.Size = new System.Drawing.Size(75, 16);
            this.lblapplydate.TabIndex = 14;
            this.lblapplydate.Text = "Apply Date";
            // 
            // lbltypeofservice
            // 
            this.lbltypeofservice.AutoSize = true;
            this.lbltypeofservice.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltypeofservice.Location = new System.Drawing.Point(4, 416);
            this.lbltypeofservice.Name = "lbltypeofservice";
            this.lbltypeofservice.Size = new System.Drawing.Size(103, 16);
            this.lbltypeofservice.TabIndex = 13;
            this.lbltypeofservice.Text = "Type of Service";
            // 
            // lblqualification
            // 
            this.lblqualification.AutoSize = true;
            this.lblqualification.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblqualification.Location = new System.Drawing.Point(17, 379);
            this.lblqualification.Name = "lblqualification";
            this.lblqualification.Size = new System.Drawing.Size(81, 16);
            this.lblqualification.TabIndex = 12;
            this.lblqualification.Text = "Qualification";
            // 
            // lblidentitynumber
            // 
            this.lblidentitynumber.AutoSize = true;
            this.lblidentitynumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblidentitynumber.Location = new System.Drawing.Point(0, 352);
            this.lblidentitynumber.Name = "lblidentitynumber";
            this.lblidentitynumber.Size = new System.Drawing.Size(101, 16);
            this.lblidentitynumber.TabIndex = 11;
            this.lblidentitynumber.Text = "Identity Number";
            // 
            // lblidentity
            // 
            this.lblidentity.AutoSize = true;
            this.lblidentity.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblidentity.Location = new System.Drawing.Point(41, 322);
            this.lblidentity.Name = "lblidentity";
            this.lblidentity.Size = new System.Drawing.Size(50, 16);
            this.lblidentity.TabIndex = 10;
            this.lblidentity.Text = "Identity";
            // 
            // lblmaritalstatus
            // 
            this.lblmaritalstatus.AutoSize = true;
            this.lblmaritalstatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmaritalstatus.Location = new System.Drawing.Point(10, 295);
            this.lblmaritalstatus.Name = "lblmaritalstatus";
            this.lblmaritalstatus.Size = new System.Drawing.Size(88, 16);
            this.lblmaritalstatus.TabIndex = 9;
            this.lblmaritalstatus.Text = "Marital Status";
            // 
            // lblgender
            // 
            this.lblgender.AutoSize = true;
            this.lblgender.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblgender.Location = new System.Drawing.Point(37, 263);
            this.lblgender.Name = "lblgender";
            this.lblgender.Size = new System.Drawing.Size(53, 16);
            this.lblgender.TabIndex = 8;
            this.lblgender.Text = "Gender";
            // 
            // lblpin
            // 
            this.lblpin.AutoSize = true;
            this.lblpin.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpin.Location = new System.Drawing.Point(64, 226);
            this.lblpin.Name = "lblpin";
            this.lblpin.Size = new System.Drawing.Size(27, 16);
            this.lblpin.TabIndex = 7;
            this.lblpin.Text = "Pin";
            // 
            // lblstate
            // 
            this.lblstate.AutoSize = true;
            this.lblstate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblstate.Location = new System.Drawing.Point(51, 158);
            this.lblstate.Name = "lblstate";
            this.lblstate.Size = new System.Drawing.Size(39, 16);
            this.lblstate.TabIndex = 6;
            this.lblstate.Text = "State";
            // 
            // lblcity
            // 
            this.lblcity.AutoSize = true;
            this.lblcity.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcity.Location = new System.Drawing.Point(60, 190);
            this.lblcity.Name = "lblcity";
            this.lblcity.Size = new System.Drawing.Size(30, 16);
            this.lblcity.TabIndex = 5;
            this.lblcity.Text = "City";
            // 
            // lblcountry
            // 
            this.lblcountry.AutoSize = true;
            this.lblcountry.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcountry.Location = new System.Drawing.Point(37, 125);
            this.lblcountry.Name = "lblcountry";
            this.lblcountry.Size = new System.Drawing.Size(53, 16);
            this.lblcountry.TabIndex = 4;
            this.lblcountry.Text = "Country";
            // 
            // lbldateofbirth
            // 
            this.lbldateofbirth.AutoSize = true;
            this.lbldateofbirth.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldateofbirth.Location = new System.Drawing.Point(18, 92);
            this.lbldateofbirth.Name = "lbldateofbirth";
            this.lbldateofbirth.Size = new System.Drawing.Size(80, 16);
            this.lbldateofbirth.TabIndex = 3;
            this.lbldateofbirth.Text = "Date of Birth";
            // 
            // lbllastname
            // 
            this.lbllastname.AutoSize = true;
            this.lbllastname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbllastname.Location = new System.Drawing.Point(18, 65);
            this.lbllastname.Name = "lbllastname";
            this.lbllastname.Size = new System.Drawing.Size(73, 16);
            this.lbllastname.TabIndex = 2;
            this.lbllastname.Text = "Last Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 78);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 1;
            // 
            // lblfirstname
            // 
            this.lblfirstname.AutoSize = true;
            this.lblfirstname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfirstname.Location = new System.Drawing.Point(18, 37);
            this.lblfirstname.Name = "lblfirstname";
            this.lblfirstname.Size = new System.Drawing.Size(73, 16);
            this.lblfirstname.TabIndex = 0;
            this.lblfirstname.Text = "First Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Image = ((System.Drawing.Image)(resources.GetObject("label5.Image")));
            this.label5.Location = new System.Drawing.Point(16, 42);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(353, 25);
            this.label5.TabIndex = 60;
            this.label5.Text = "Passport Visa Processing Solutions";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::PassportSevaNew.Properties.Resources.header2;
            this.pictureBox2.Location = new System.Drawing.Point(0, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(867, 112);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 59;
            this.pictureBox2.TabStop = false;
            // 
            // ApplyPassport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(884, 612);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.shapeContainer1);
            this.Location = new System.Drawing.Point(30, 30);
            this.MaximumSize = new System.Drawing.Size(900, 650);
            this.Name = "ApplyPassport";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Apply Passport";
            this.Load += new System.EventHandler(this.ApplyPassport_Load);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.grpboxbooklettype.ResumeLayout(false);
            this.grpboxbooklettype.PerformLayout();
            this.grpboxtypeofservice.ResumeLayout(false);
            this.grpboxtypeofservice.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button hbtnchnfpass;
        private System.Windows.Forms.Button hbtnrisspass;
        private System.Windows.Forms.Button hbtnapplyvisa;
        private System.Windows.Forms.Button hbtnvisacncl;
        private System.Windows.Forms.Button hbtnapply;
        private System.Windows.Forms.Label label2;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox grpboxbooklettype;
        private System.Windows.Forms.RadioButton rbtn30pages;
        private System.Windows.Forms.RadioButton rbtn60pages;
        private System.Windows.Forms.GroupBox grpboxtypeofservice;
        private System.Windows.Forms.RadioButton rbtnnormal;
        private System.Windows.Forms.RadioButton rbtntatkal;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbtnmale;
        private System.Windows.Forms.RadioButton rbtnfemale;
        private System.Windows.Forms.DateTimePicker txtapplydate;
        private System.Windows.Forms.ComboBox ddlqualification;
        private System.Windows.Forms.TextBox txtidentitynumber;
        private System.Windows.Forms.ComboBox ddlidentity;
        private System.Windows.Forms.ComboBox ddlmaritalstatus;
        private System.Windows.Forms.TextBox txtpin;
        private System.Windows.Forms.ComboBox ddlcity;
        private System.Windows.Forms.ComboBox ddlstate;
        private System.Windows.Forms.ComboBox ddlcountry;
        private System.Windows.Forms.DateTimePicker txtdateofbirth;
        private System.Windows.Forms.TextBox txtlastname;
        private System.Windows.Forms.TextBox txtfirstname;
        private System.Windows.Forms.Button btncancel;
        private System.Windows.Forms.Button btnsubmit;
        private System.Windows.Forms.Label lblbooklettype;
        private System.Windows.Forms.Label lblapplydate;
        private System.Windows.Forms.Label lbltypeofservice;
        private System.Windows.Forms.Label lblqualification;
        private System.Windows.Forms.Label lblidentitynumber;
        private System.Windows.Forms.Label lblidentity;
        private System.Windows.Forms.Label lblmaritalstatus;
        private System.Windows.Forms.Label lblgender;
        private System.Windows.Forms.Label lblpin;
        private System.Windows.Forms.Label lblstate;
        private System.Windows.Forms.Label lblcity;
        private System.Windows.Forms.Label lblcountry;
        private System.Windows.Forms.Label lbldateofbirth;
        private System.Windows.Forms.Label lbllastname;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblfirstname;
        private System.Windows.Forms.Label errapplydate;
        private System.Windows.Forms.Label errlname;
        private System.Windows.Forms.Label errpin;
        private System.Windows.Forms.Label errdob;
        private System.Windows.Forms.Label errfname;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}

