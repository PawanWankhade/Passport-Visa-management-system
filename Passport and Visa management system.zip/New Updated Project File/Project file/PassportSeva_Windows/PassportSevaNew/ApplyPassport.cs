﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using MainDllLibrary;
using System.Configuration;

namespace PassportSevaNew
{
    public partial class ApplyPassport : Form
    {
        string uid="";
        
        
        public string hfname = "", hlname = "";
        public bool flag1 = true,flag2=true,flag3=true,flag4=true,flag5=true,flag6=true;
        public ApplyPassport()
        {
            InitializeComponent();
        }
        public ApplyPassport(string userid)
        {
            InitializeComponent();
            uid = userid;


            txtdateofbirth.Text = "";
            ddlcountry.Items.Add("India");


            ddlmaritalstatus.Items.Add("Married");
            ddlmaritalstatus.Items.Add("Unmarried");
            ddlmaritalstatus.Items.Add("Divorced");


            ddlidentity.Items.Add("PAN");
            ddlidentity.Items.Add("Voter ID");
            ddlidentity.Items.Add("Aadhar card");


            ddlqualification.Items.Add("Under Graduate");
            ddlqualification.Items.Add("Graduate");
            ddlqualification.Items.Add("Post Graduate");

            GenerateFields generate = new GenerateFields();
            string s = ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString;


            generate.OpenConnection(s);
            DataSet ds = generate.GetStates();

            ddlstate.DataSource = ds.Tables[0];

            ddlstate.ValueMember = ds.Tables[0].Columns["sid"].ToString();
            ddlstate.DisplayMember = "sname";
            DataSet d1 = generate.GetCities("S_A001");
            ddlcity.DataSource = d1.Tables[0];
            ddlcity.ValueMember = d1.Tables["cities"].Columns[1].ToString();
            ddlstate.DisplayMember = "city";



            generate.CloseConnection();

        }     

        private void hbtnapply_Click(object sender, EventArgs e)
        {
            ApplyPassport ap = new ApplyPassport(uid);
            ap.Show();
            this.Hide();
        }

        private void hbtnrisspass_Click(object sender, EventArgs e)
        {
            ReissuePassport rp = new ReissuePassport(uid);
            rp.Show();
            this.Hide();
        }

        private void hbtnapplyvisa_Click(object sender, EventArgs e)
        {
            ApplyVisa av = new ApplyVisa(uid);
            av.Show();
            this.Hide();
        }

        private void hbtnvisacncl_Click(object sender, EventArgs e)
        {
            VisaCancellation vc = new VisaCancellation(uid);
            vc.Show();
            this.Hide();
        }

        private void hbtnchnfpass_Click(object sender, EventArgs e)
        {
            ChangePassword c = new ChangePassword(uid);
            c.Show();
            this.Hide();
        }

        private void ApplyPassport_Load(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void btnsubmit_Click_1(object sender, EventArgs e)
        {

            //validation for first name
            Regex r = new Regex("^([a-zA-Z]+( [a-zA-Z]+)*)$");

            if (!(r.IsMatch(txtfirstname.Text)))
            {

                errfname.Text = "First name should contain alphabets only";
                errfname.ForeColor = System.Drawing.Color.Red;
                flag1 = false;
            }
            else
            {
                errfname.Text = "";
                flag1 = true;
            }

            //validation for last name
            if (!(r.IsMatch(txtlastname.Text)))
            {
                errlname.Text = "Last name should contain alphabets only";
                errlname.ForeColor = System.Drawing.Color.Red;
                flag2 = false;
            }
            else
            {
                errlname.Text = "";
                flag2 = true;
            }

            //validation for pin 
            Regex r1 = new Regex("^[0-9]{6}$");

            if (!(r1.IsMatch(txtpin.Text)))
            {
                errpin.Text = "Please enter correct pincode";
                errpin.ForeColor = System.Drawing.Color.Red;
                flag3 = false;
            }
            else
            {
                errpin.Text = "";
                flag3 = true;
            }

            //validation for date of birth
            if (txtdateofbirth.Value > DateTime.Today)
            {
                errdob.Text = "Please enter a valid date";
                errdob.ForeColor = System.Drawing.Color.Red;
                flag4 = false;
            }
            else
            {
                errdob.Text = "";
                flag4 = true;
            }

            //validation for apply date
            if (txtapplydate.Value < DateTime.Today)
            {
                errapplydate.Text = "Please enter a valid apply date";
                errapplydate.ForeColor = System.Drawing.Color.Red;
                flag5 = false;
            }
            else
            {
                errdob.Text = "";
                flag5 = true;
            }



            //validation for required field
            if (txtapplydate.Text == "" || txtdateofbirth.Text == "" || txtfirstname.Text == "" || txtlastname.Text == "" || txtpin.Text == "" || ddlcity.SelectedItem == null || ddlcountry.SelectedItem == null || ddlmaritalstatus.SelectedItem == null || ddlqualification.SelectedItem == null || ddlstate.SelectedItem == null || !(rbtn30pages.Checked || rbtn60pages.Checked) || !(rbtnfemale.Checked || rbtnmale.Checked) || !(rbtnnormal.Checked || rbtntatkal.Checked))
            {
                flag6 = false;
            }

            else
                flag6 = true;


            if (flag1 == true && flag2 == true && flag3 == true && flag4 == true && flag5 == true && flag6 == true)
            {
                Passport passport = new Passport();
                passport.ApplyDate = DateTime.Now;

                if (rbtn30pages.Checked)
                {
                    passport.BookletType = 30;
                }

                else if (rbtn60pages.Checked)
                {
                    passport.BookletType = 60;
                }
                passport.Country = ddlcountry.Text;

                passport.Dob = Convert.ToDateTime(txtdateofbirth.Text);
                passport.Fname = txtfirstname.Text;
                passport.Lname = txtlastname.Text;
                passport.Uid = uid;



                passport.Marital = this.ddlmaritalstatus.GetItemText(this.ddlmaritalstatus.SelectedItem);
                passport.Pin = Convert.ToInt32(txtpin.Text);
                passport.Qualification = this.ddlqualification.GetItemText(this.ddlqualification.SelectedItem);
                passport.State = ddlstate.Text;
                passport.City = ddlcity.Text;
                if (rbtnnormal.Checked)
                {
                    passport.TypeofService = rbtnnormal.Text;
                }
                else if (rbtntatkal.Checked)
                {
                    passport.TypeofService = rbtntatkal.Text;
                }

                if (rbtnmale.Checked)
                {
                    passport.Gender = rbtnmale.Text;
                }

                else if (rbtnfemale.Checked)
                {
                    passport.Gender = rbtnfemale.Text;
                }
                passport.IssueDate = (DateTime.Now).AddDays(10);
                passport.ExpiryDate = (DateTime.Now).AddYears(10);

                string id = "";
                if (ddlidentity.SelectedItem == null)
                {
                    id = "";
                }
                else
                {
                    if (ddlidentity.SelectedItem.ToString() == "PAN")
                        id = "PAN-" + txtidentitynumber.Text;
                    if (ddlidentity.SelectedItem.ToString() == "Voter ID")
                        id = "VID-" + txtidentitynumber.Text;
                    if (ddlidentity.SelectedItem.ToString() == "Aadhhar Card")
                        id = "AID-" + txtidentitynumber.Text;
                }
                

                passport.Identity = id;

                PassportConnect connect = new PassportConnect();
                try
                {
                    string s = ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString;


                    connect.OpenConnection(s);
                    Passport flag = connect.InsertPassport(passport);

                    if (flag.PID != "")
                    {
                        Success success = new Success(flag.PID, flag.Amount, flag.ExpiryDate,flag.Uid);
                        success.Show();
                        this.Hide();
                    }

                    connect.CloseConnection();
                }
                catch (Exception ex)
                {
                    Error err = new Error();
                    err.Show();
                    this.Hide();
                }

            }
            else
            {
                MessageBox.Show("please fill all required fields properly");
            }
        }

        private void btncancel_Click_1(object sender, EventArgs e)
        {
            Home h = new Home();
            h.Show();
            this.Hide();
        }

        private void ddlstate_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            string id = ddlstate.SelectedValue.ToString();

            string s = ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString;


            GenerateFields generate = new GenerateFields();
            generate.OpenConnection(s);
            DataSet ds = generate.GetCities(id);
            ddlcity.DataSource = ds.Tables[0];
            ddlcity.DisplayMember = "city";
            generate.CloseConnection();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            User user = new User();
            UserConnection ucon = new UserConnection();
            ucon.OpenConnection(ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString);
            user = ucon.GetUserById(uid);
            ucon.CloseConnection();

            txtfirstname.Text = user.Fname;
            txtfirstname.ReadOnly = true;
            txtlastname.Text = user.Lname;
            txtlastname.ReadOnly = true;

            txtdateofbirth.Text = user.Dob.ToString();
            txtdateofbirth.Enabled = false;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            txtfirstname.Text = "";
            txtfirstname.ReadOnly = false;
            txtlastname.Text = "";
            txtlastname.ReadOnly = false;
            txtdateofbirth.Text = "";
            txtdateofbirth.Enabled = true;
        }

        private void grpboxbooklettype_Enter(object sender, EventArgs e)
        {

        }

      








    }
}




