﻿namespace PassportSevaNew
{
    partial class VisaCancellation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(VisaCancellation));
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblerr = new System.Windows.Forms.Label();
            this.lblcancel = new System.Windows.Forms.Button();
            this.btnsubmit = new System.Windows.Forms.Button();
            this.ddlhintque = new System.Windows.Forms.ComboBox();
            this.txthintans = new System.Windows.Forms.TextBox();
            this.txtemailid = new System.Windows.Forms.TextBox();
            this.txtuserid = new System.Windows.Forms.TextBox();
            this.lblhintanswer = new System.Windows.Forms.Label();
            this.lblhintquestion = new System.Windows.Forms.Label();
            this.lblemailid = new System.Windows.Forms.Label();
            this.lbluserid = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblerr2 = new System.Windows.Forms.Label();
            this.btncancel2 = new System.Windows.Forms.Button();
            this.btnsubmit2 = new System.Windows.Forms.Button();
            this.txtvisaid = new System.Windows.Forms.TextBox();
            this.txtpassportid = new System.Windows.Forms.TextBox();
            this.txtuserid2 = new System.Windows.Forms.TextBox();
            this.lblvisaid = new System.Windows.Forms.Label();
            this.lblpassportid = new System.Windows.Forms.Label();
            this.lbluserid2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.hbtnchnfpass = new System.Windows.Forms.Button();
            this.hbtnrisspass = new System.Windows.Forms.Button();
            this.hbtnapplyvisa = new System.Windows.Forms.Button();
            this.hbtnvisacncl = new System.Windows.Forms.Button();
            this.hbtnapply = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.lblerr);
            this.panel1.Controls.Add(this.lblcancel);
            this.panel1.Controls.Add(this.btnsubmit);
            this.panel1.Controls.Add(this.ddlhintque);
            this.panel1.Controls.Add(this.txthintans);
            this.panel1.Controls.Add(this.txtemailid);
            this.panel1.Controls.Add(this.txtuserid);
            this.panel1.Controls.Add(this.lblhintanswer);
            this.panel1.Controls.Add(this.lblhintquestion);
            this.panel1.Controls.Add(this.lblemailid);
            this.panel1.Controls.Add(this.lbluserid);
            this.panel1.Location = new System.Drawing.Point(270, 225);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(294, 294);
            this.panel1.TabIndex = 2;
            // 
            // lblerr
            // 
            this.lblerr.AutoSize = true;
            this.lblerr.Location = new System.Drawing.Point(30, 192);
            this.lblerr.Name = "lblerr";
            this.lblerr.Size = new System.Drawing.Size(0, 13);
            this.lblerr.TabIndex = 10;
            // 
            // lblcancel
            // 
            this.lblcancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcancel.Location = new System.Drawing.Point(150, 248);
            this.lblcancel.Name = "lblcancel";
            this.lblcancel.Size = new System.Drawing.Size(75, 23);
            this.lblcancel.TabIndex = 6;
            this.lblcancel.Text = "Cancel";
            this.lblcancel.UseVisualStyleBackColor = true;
            this.lblcancel.Click += new System.EventHandler(this.lblcancel_Click_1);
            // 
            // btnsubmit
            // 
            this.btnsubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsubmit.Location = new System.Drawing.Point(30, 248);
            this.btnsubmit.Name = "btnsubmit";
            this.btnsubmit.Size = new System.Drawing.Size(75, 23);
            this.btnsubmit.TabIndex = 5;
            this.btnsubmit.Text = "Submit";
            this.btnsubmit.UseVisualStyleBackColor = true;
            this.btnsubmit.Click += new System.EventHandler(this.btnsubmit_Click_1);
            // 
            // ddlhintque
            // 
            this.ddlhintque.FormattingEnabled = true;
            this.ddlhintque.Location = new System.Drawing.Point(136, 130);
            this.ddlhintque.Name = "ddlhintque";
            this.ddlhintque.Size = new System.Drawing.Size(140, 21);
            this.ddlhintque.TabIndex = 3;
            // 
            // txthintans
            // 
            this.txthintans.Location = new System.Drawing.Point(136, 172);
            this.txthintans.Name = "txthintans";
            this.txthintans.Size = new System.Drawing.Size(140, 20);
            this.txthintans.TabIndex = 4;
            // 
            // txtemailid
            // 
            this.txtemailid.Location = new System.Drawing.Point(136, 82);
            this.txtemailid.Name = "txtemailid";
            this.txtemailid.Size = new System.Drawing.Size(140, 20);
            this.txtemailid.TabIndex = 2;
            // 
            // txtuserid
            // 
            this.txtuserid.Location = new System.Drawing.Point(136, 42);
            this.txtuserid.Name = "txtuserid";
            this.txtuserid.Size = new System.Drawing.Size(140, 20);
            this.txtuserid.TabIndex = 1;
            // 
            // lblhintanswer
            // 
            this.lblhintanswer.AutoSize = true;
            this.lblhintanswer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblhintanswer.Location = new System.Drawing.Point(27, 176);
            this.lblhintanswer.Name = "lblhintanswer";
            this.lblhintanswer.Size = new System.Drawing.Size(78, 16);
            this.lblhintanswer.TabIndex = 3;
            this.lblhintanswer.Text = "Hint Answer";
            // 
            // lblhintquestion
            // 
            this.lblhintquestion.AutoSize = true;
            this.lblhintquestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblhintquestion.Location = new System.Drawing.Point(24, 135);
            this.lblhintquestion.Name = "lblhintquestion";
            this.lblhintquestion.Size = new System.Drawing.Size(87, 16);
            this.lblhintquestion.TabIndex = 2;
            this.lblhintquestion.Text = "Hint Question";
            // 
            // lblemailid
            // 
            this.lblemailid.AutoSize = true;
            this.lblemailid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblemailid.Location = new System.Drawing.Point(27, 93);
            this.lblemailid.Name = "lblemailid";
            this.lblemailid.Size = new System.Drawing.Size(58, 16);
            this.lblemailid.TabIndex = 1;
            this.lblemailid.Text = "Email ID";
            // 
            // lbluserid
            // 
            this.lbluserid.AutoSize = true;
            this.lbluserid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbluserid.Location = new System.Drawing.Point(24, 47);
            this.lbluserid.Name = "lbluserid";
            this.lbluserid.Size = new System.Drawing.Size(53, 16);
            this.lbluserid.TabIndex = 0;
            this.lbluserid.Text = "User ID";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lblerr2);
            this.panel2.Controls.Add(this.btncancel2);
            this.panel2.Controls.Add(this.btnsubmit2);
            this.panel2.Controls.Add(this.txtvisaid);
            this.panel2.Controls.Add(this.txtpassportid);
            this.panel2.Controls.Add(this.txtuserid2);
            this.panel2.Controls.Add(this.lblvisaid);
            this.panel2.Controls.Add(this.lblpassportid);
            this.panel2.Controls.Add(this.lbluserid2);
            this.panel2.Location = new System.Drawing.Point(306, 225);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(356, 294);
            this.panel2.TabIndex = 56;
            // 
            // lblerr2
            // 
            this.lblerr2.AutoSize = true;
            this.lblerr2.Location = new System.Drawing.Point(37, 192);
            this.lblerr2.Name = "lblerr2";
            this.lblerr2.Size = new System.Drawing.Size(0, 13);
            this.lblerr2.TabIndex = 10;
            // 
            // btncancel2
            // 
            this.btncancel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncancel2.Location = new System.Drawing.Point(203, 207);
            this.btncancel2.Name = "btncancel2";
            this.btncancel2.Size = new System.Drawing.Size(75, 23);
            this.btncancel2.TabIndex = 5;
            this.btncancel2.Text = "Cancel";
            this.btncancel2.UseVisualStyleBackColor = true;
            this.btncancel2.Click += new System.EventHandler(this.btncancel2_Click_1);
            // 
            // btnsubmit2
            // 
            this.btnsubmit2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsubmit2.Location = new System.Drawing.Point(55, 207);
            this.btnsubmit2.Name = "btnsubmit2";
            this.btnsubmit2.Size = new System.Drawing.Size(75, 23);
            this.btnsubmit2.TabIndex = 4;
            this.btnsubmit2.Text = "Submit";
            this.btnsubmit2.UseVisualStyleBackColor = true;
            this.btnsubmit2.Click += new System.EventHandler(this.btnsubmit2_Click);
            // 
            // txtvisaid
            // 
            this.txtvisaid.Location = new System.Drawing.Point(138, 135);
            this.txtvisaid.Name = "txtvisaid";
            this.txtvisaid.Size = new System.Drawing.Size(140, 20);
            this.txtvisaid.TabIndex = 3;
            // 
            // txtpassportid
            // 
            this.txtpassportid.Location = new System.Drawing.Point(138, 89);
            this.txtpassportid.Name = "txtpassportid";
            this.txtpassportid.Size = new System.Drawing.Size(140, 20);
            this.txtpassportid.TabIndex = 2;
            // 
            // txtuserid2
            // 
            this.txtuserid2.Enabled = false;
            this.txtuserid2.Location = new System.Drawing.Point(138, 43);
            this.txtuserid2.Name = "txtuserid2";
            this.txtuserid2.Size = new System.Drawing.Size(140, 20);
            this.txtuserid2.TabIndex = 1;
            // 
            // lblvisaid
            // 
            this.lblvisaid.AutoSize = true;
            this.lblvisaid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblvisaid.Location = new System.Drawing.Point(34, 135);
            this.lblvisaid.Name = "lblvisaid";
            this.lblvisaid.Size = new System.Drawing.Size(51, 16);
            this.lblvisaid.TabIndex = 2;
            this.lblvisaid.Text = "Visa ID";
            // 
            // lblpassportid
            // 
            this.lblpassportid.AutoSize = true;
            this.lblpassportid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpassportid.Location = new System.Drawing.Point(28, 93);
            this.lblpassportid.Name = "lblpassportid";
            this.lblpassportid.Size = new System.Drawing.Size(78, 16);
            this.lblpassportid.TabIndex = 1;
            this.lblpassportid.Text = "Passport ID";
            // 
            // lbluserid2
            // 
            this.lbluserid2.AutoSize = true;
            this.lbluserid2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbluserid2.Location = new System.Drawing.Point(28, 43);
            this.lbluserid2.Name = "lbluserid2";
            this.lbluserid2.Size = new System.Drawing.Size(53, 16);
            this.lbluserid2.TabIndex = 0;
            this.lbluserid2.Text = "User ID";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.hbtnchnfpass);
            this.panel3.Controls.Add(this.hbtnrisspass);
            this.panel3.Controls.Add(this.hbtnapplyvisa);
            this.panel3.Controls.Add(this.hbtnvisacncl);
            this.panel3.Controls.Add(this.hbtnapply);
            this.panel3.Location = new System.Drawing.Point(0, 196);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(219, 429);
            this.panel3.TabIndex = 54;
            // 
            // hbtnchnfpass
            // 
            this.hbtnchnfpass.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hbtnchnfpass.Location = new System.Drawing.Point(9, 293);
            this.hbtnchnfpass.Name = "hbtnchnfpass";
            this.hbtnchnfpass.Size = new System.Drawing.Size(140, 30);
            this.hbtnchnfpass.TabIndex = 5;
            this.hbtnchnfpass.Text = "Change Password";
            this.hbtnchnfpass.UseVisualStyleBackColor = true;
            this.hbtnchnfpass.Click += new System.EventHandler(this.hbtnchnfpass_Click);
            // 
            // hbtnrisspass
            // 
            this.hbtnrisspass.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hbtnrisspass.Location = new System.Drawing.Point(9, 93);
            this.hbtnrisspass.Name = "hbtnrisspass";
            this.hbtnrisspass.Size = new System.Drawing.Size(140, 30);
            this.hbtnrisspass.TabIndex = 4;
            this.hbtnrisspass.Text = "Reissue Passport";
            this.hbtnrisspass.UseVisualStyleBackColor = true;
            this.hbtnrisspass.Click += new System.EventHandler(this.hbtnrisspass_Click);
            // 
            // hbtnapplyvisa
            // 
            this.hbtnapplyvisa.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hbtnapplyvisa.Location = new System.Drawing.Point(9, 157);
            this.hbtnapplyvisa.Name = "hbtnapplyvisa";
            this.hbtnapplyvisa.Size = new System.Drawing.Size(140, 30);
            this.hbtnapplyvisa.TabIndex = 3;
            this.hbtnapplyvisa.Text = "Apply for Visa";
            this.hbtnapplyvisa.UseVisualStyleBackColor = true;
            this.hbtnapplyvisa.Click += new System.EventHandler(this.hbtnapplyvisa_Click);
            // 
            // hbtnvisacncl
            // 
            this.hbtnvisacncl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hbtnvisacncl.Location = new System.Drawing.Point(9, 224);
            this.hbtnvisacncl.Name = "hbtnvisacncl";
            this.hbtnvisacncl.Size = new System.Drawing.Size(140, 30);
            this.hbtnvisacncl.TabIndex = 2;
            this.hbtnvisacncl.Text = "Visa Cancellation";
            this.hbtnvisacncl.UseVisualStyleBackColor = true;
            this.hbtnvisacncl.Click += new System.EventHandler(this.hbtnvisacncl_Click);
            // 
            // hbtnapply
            // 
            this.hbtnapply.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hbtnapply.Location = new System.Drawing.Point(9, 36);
            this.hbtnapply.Name = "hbtnapply";
            this.hbtnapply.Size = new System.Drawing.Size(140, 30);
            this.hbtnapply.TabIndex = 1;
            this.hbtnapply.Text = "Apply for Passport";
            this.hbtnapply.UseVisualStyleBackColor = true;
            this.hbtnapply.Click += new System.EventHandler(this.hbtnapply_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(251, 130);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(154, 24);
            this.label2.TabIndex = 55;
            this.label2.Text = "Visa Cancellation";
            // 
            // lineShape1
            // 
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 242;
            this.lineShape1.X2 = 881;
            this.lineShape1.Y1 = 164;
            this.lineShape1.Y2 = 164;
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(884, 612);
            this.shapeContainer1.TabIndex = 57;
            this.shapeContainer1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Image = ((System.Drawing.Image)(resources.GetObject("label1.Image")));
            this.label1.Location = new System.Drawing.Point(37, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(353, 25);
            this.label1.TabIndex = 5;
            this.label1.Text = "Passport Visa Processing Solutions";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::PassportSevaNew.Properties.Resources.header2;
            this.pictureBox1.Location = new System.Drawing.Point(0, 1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(883, 112);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // VisaCancellation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(884, 612);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.shapeContainer1);
            this.Location = new System.Drawing.Point(30, 30);
            this.MaximumSize = new System.Drawing.Size(900, 650);
            this.Name = "VisaCancellation";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "VisaCancellation";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblerr;
        private System.Windows.Forms.Button lblcancel;
        private System.Windows.Forms.Button btnsubmit;
        private System.Windows.Forms.ComboBox ddlhintque;
        private System.Windows.Forms.TextBox txthintans;
        private System.Windows.Forms.TextBox txtemailid;
        private System.Windows.Forms.TextBox txtuserid;
        private System.Windows.Forms.Label lblhintanswer;
        private System.Windows.Forms.Label lblhintquestion;
        private System.Windows.Forms.Label lblemailid;
        private System.Windows.Forms.Label lbluserid;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button hbtnchnfpass;
        private System.Windows.Forms.Button hbtnrisspass;
        private System.Windows.Forms.Button hbtnapplyvisa;
        private System.Windows.Forms.Button hbtnvisacncl;
        private System.Windows.Forms.Button hbtnapply;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblerr2;
        private System.Windows.Forms.Button btncancel2;
        private System.Windows.Forms.Button btnsubmit2;
        private System.Windows.Forms.TextBox txtvisaid;
        private System.Windows.Forms.TextBox txtpassportid;
        private System.Windows.Forms.TextBox txtuserid2;
        private System.Windows.Forms.Label lblvisaid;
        private System.Windows.Forms.Label lblpassportid;
        private System.Windows.Forms.Label lbluserid2;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;


    }
}