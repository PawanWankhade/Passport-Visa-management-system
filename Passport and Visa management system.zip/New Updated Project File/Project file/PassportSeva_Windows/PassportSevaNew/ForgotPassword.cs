﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MainDllLibrary;
using System.Configuration;

namespace PassportSevaNew
{
    public partial class ForgotPassword : Form
    {
        public ForgotPassword()
        {
            InitializeComponent();
            fpcomboque.Items.Add("Who is your favourite actor?");
            fpcomboque.Items.Add("Who is your first Maths teacher?");
            fpcomboque.Items.Add("What is your favourite game?");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool flag1 = true;
            if (fptxtans.Text == "" || fptxtemail.Text == "" || fptxtuid.Text == "" || fpcomboque.SelectedItem == null)
            {
                flag1 = false;
            }

            else
                flag1 = true;

            if (flag1 == true)
            {


                User u = new User();
                u.Uid = fptxtuid.Text;
                u.Email = fptxtemail.Text;
                u.Question = fpcomboque.Text;
                u.Answer = fptxtans.Text;


                UserConnection ucon = new UserConnection();
                string s = ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString;

                ucon.OpenConnection(s);
                bool b = ucon.ValidateUserDetails(u);
                if (b == true)
                {
                    Credentials c = new Credentials();
                    Credentials c1 = c.NewPassword();
                    c1.uid = fptxtuid.Text;
                    bool flag = ucon.updateforgotpassword(c1);
                    if (flag == true)
                    {
                        Success s1 = new Success(c1.password);
                        s1.Show();
                        this.Hide();
                    }
                    else
                        MessageBox.Show("Error");
                }
                else
                {
                    MessageBox.Show("Please enter valid details");

                }
                ucon.CloseConnection();
            }
            else
                MessageBox.Show("Please enter all the required fields");
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            LoginUser lu = new LoginUser();
            lu.Show();
            this.Hide();
        }
    }
}
