﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MainDllLibrary;

namespace PassportSevaNew
{
    public partial class Home : Form
    {
        string userid;
        public string hfname = "",hlname="";
        public DateTime hdob;

        public Home()
        {
            InitializeComponent();
            
        }
        public Home(string uid)
        {
            InitializeComponent();
            userid = uid;
        }


        public Home(string fname, string lname,string uid,DateTime dob)
        {
            InitializeComponent();
            hfname = fname;
            hlname =lname;
            hdob = dob;
            label1.Text = "WELCOME " + fname.ToUpper();
            userid = uid;
        }

      

        private void hbtnlogout_Click(object sender, EventArgs e)
        {
            LoginUser lu = new LoginUser();
            lu.Show();
            this.Hide();
        }

        private void hbtnapply_Click(object sender, EventArgs e)
        {
            ApplyPassport ap = new ApplyPassport(userid);
            ap.Show();
            this.Hide();
        }

        private void hbtnrisspass_Click_1(object sender, EventArgs e)
        {
            ReissuePassport rp = new ReissuePassport(userid);
            rp.Show();
            this.Hide();
        }

        private void hbtnapplyvisa_Click_1(object sender, EventArgs e)
        {
            ApplyVisa av = new ApplyVisa(userid);
            av.Show();
            this.Hide();
        }

        private void hbtnvisacncl_Click(object sender, EventArgs e)
        {
            VisaCancellation vc = new VisaCancellation(userid);
            vc.Show();
            this.Hide();
        }

        private void hbtnchnfpass_Click_1(object sender, EventArgs e)
        {

            ChangePassword c = new ChangePassword(userid);
            c.Show();
            this.Hide();
        }

       
       
    }
}
