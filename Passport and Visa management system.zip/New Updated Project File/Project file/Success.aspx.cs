﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Success : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string type = Request.QueryString["type"].ToString();
        if (type == "register")
        {
            lblHeading.Text = "User Registration Successfull";
            lblDetailsTitle.Text = "User Details";
            lblDetails.Text = "User ID &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + "<span style=\"Color:#2780e3;\">" + Request.QueryString["uid"] + "</span><br />";
            if (Session["pass"] == null || Session["pass"].ToString() == "")
            {
                Response.Redirect("Default.aspx");
            }
            lblDetails.Text += "Password  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;   " + "<span style=\"Color:#2780e3;\">" + Session["pass"] + "</span><br />";
            Session["pass"] = null;
        }
        if (type=="forgotPassword")
        {
            if (Session["pass"] == null || Session["pass"] == "")
            {
                Response.Redirect("Default.apsx");
            }
            lblHeading.Text = "New Password Details";
            lblDetailsTitle.Text = "Your New Password is : ";
            lblDetailsTitle.Text += "<span style=\"Color:#2780e3;\">"+Session["pass"]+"</span>";
            Session["pass"] = null;
        }
        
      

    }
}