﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MainDllLibrary;
using System.Data;
using System.Configuration;

public partial class User_Apply_passport : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["uid"] == null || Session["uid"].ToString() == "")
        {
            Response.Redirect("../Default.aspx");
        }
        if (!IsPostBack)
        {
            GenerateFields generate = new GenerateFields();
            try
            {
                txtIdentity.Enabled = false;
                PanValidator.Enabled = false;
                AadharValidator.Enabled = false;
                VoterIDValidator.Enabled = false;
                string s = ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString;
                generate.OpenConnection(s);
                DataSet ds = generate.GetStates();
                apddlState.DataSource = ds;
                apddlState.DataTextField = ds.Tables[0].Columns[1].ToString();
                apddlState.DataValueField = ds.Tables[0].Columns[0].ToString();
                apddlState.DataBind();

                aptxtapplydate.Text = DateTime.Now.Date.ToString().Substring(0, 9);
             
                generate.OpenConnection(s);
                ds = generate.GetCities("S_A001");
                apddlcity.DataSource = ds;
                apddlcity.DataTextField = ds.Tables["cities"].Columns[1].ToString();
                apddlcity.DataBind();

            }
            catch (Exception)
            {
                Response.Redirect("Error.aspx");
            }
            finally
            {
                generate.CloseConnection();
            }

        }
    }

    protected void CheckDate(object source, ServerValidateEventArgs e)
    {
        DateTime dt = Convert.ToDateTime(aptxtDob.Text);
        if (dt.CompareTo(DateTime.Now) != 1)
        {
            e.IsValid = true;
        }
        else
        {
            e.IsValid = false;
        }
    }


    protected void apbtnSave_Click(object sender, EventArgs e)
    {
        string id = apddlState.SelectedItem.Value;
        string s = ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString;
        GenerateFields generate = new GenerateFields();
        generate.OpenConnection(s);
        DataSet ds = generate.GetCities(id);

        apddlcity.DataSource = ds;
        apddlcity.DataTextField = ds.Tables["cities"].Columns[1].ToString();
        apddlcity.DataBind();
        generate.CloseConnection();
    }
    protected void apddlIdentity_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (apddlIdentity.SelectedItem.Value == "0")
        {
            txtIdentity.Enabled = false;
            txtIdentity.Text = "";
        }
        else
        {
            txtIdentity.Enabled = true;
        }
        lblIdentityInput.Text = apddlIdentity.SelectedItem.Text + " Number";

        switch (apddlIdentity.SelectedItem.Text)
        {
            case "PAN": PanValidator.Enabled = true;
                AadharValidator.Enabled = false;
                VoterIDValidator.Enabled = false;
                break;

            case "Voter ID": PanValidator.Enabled = false;
                AadharValidator.Enabled = false;
                VoterIDValidator.Enabled = true;
                break;

            case "Aadhhar Card":
                PanValidator.Enabled = false;
                AadharValidator.Enabled = true;
                VoterIDValidator.Enabled = false;
                break;

        }
        

    }
    protected void apbtnSave_Click1(object sender, EventArgs e)
    {
        if (IsValid)
        {
            Passport passport = new Passport();
            passport.ApplyDate = DateTime.Now;
            passport.BookletType = Convert.ToInt32(aprdbooklettype.SelectedItem.Value);
            passport.City = apddlcity.SelectedItem.Text;
            passport.Country = apddlCountry.SelectedItem.Text;
            passport.Dob = Convert.ToDateTime(aptxtDob.Text);
            passport.Fname = aptxtFname.Text;
            passport.Lname = aptxtLname.Text;
            passport.Marital = apddlMarStatus.SelectedItem.Text;
            passport.Pin = Convert.ToInt32(txtpin.Text);
            passport.Qualification = apdropQualification.SelectedItem.Text;
            passport.State = apddlState.SelectedItem.Text;
            passport.TypeofService = aprdtypeofservice.SelectedItem.Text;
            passport.Gender = rdbtnGender.SelectedItem.Text;
            passport.IssueDate = (DateTime.Now).AddDays(10);
            passport.ExpiryDate = (DateTime.Now).AddYears(10);

            string id = "";
            if (apddlIdentity.SelectedItem.Text == "PAN")
                id = "PAN-" + txtIdentity.Text;
            if (apddlIdentity.SelectedItem.Text == "Voter ID")
                id = "VID-" + txtIdentity.Text;
            if (apddlIdentity.SelectedItem.Text == "Aadhhar Card")
                id = "AID-" + txtIdentity.Text;
            if (txtIdentity.Text == "")
            {
                id = "";
            }

            passport.Identity = id;
            if (Session["uid"] != null)
                passport.Uid = Session["uid"].ToString();

            else
                Response.Redirect("../Error.aspx?type=expire");

            PassportConnect connect = new PassportConnect();
            try
            {
                string s = ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString;


                connect.OpenConnection(s);
                Passport flag = connect.InsertPassport(passport);

                if (flag.PID != "")
                {
                    Response.Redirect("Success.aspx?type=passportRegistration&pid=" + flag.PID + "&amount=" + flag.Amount + "&expiry=" + flag.ExpiryDate + "&issue=" + flag.IssueDate);
                }
                else
                {
                    Response.Redirect("../Error.aspx");
                }
                connect.CloseConnection();
            }
            catch (Exception)
            {
              
            }
        }
        else
        {
            CustomValidator1.ErrorMessage = "Please Enter valid date of birth";
        }


    }
    protected void apbtnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("WelcomeUser.aspx");
    }

    protected void rdlistApplyingfor_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (Session["uid"] == null || Session["uid"].ToString() == "")
        {
            Response.Redirect("../Default.aspx");
        }
        string uid = Session["uid"].ToString();
        if (rdlistApplyingfor.SelectedItem.Text == "Yourself")
        {

            UserConnection ucon = new UserConnection();
            ucon.OpenConnection(ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString);
            User user = new User();
            user = ucon.GetUserById(uid);
            if (user.Uid == "error")
            {
                Response.Redirect("Error.aspx");
            }
            aptxtFname.Text = user.Fname;
            aptxtLname.Text = user.Lname;
            DateTime dob = user.Dob;
            aptxtDob.Text = dob.ToString("yyyy-MM-dd");
            aptxtDob.ReadOnly= true;

            if (user.Gender == "Male")
            {
                rdbtnGender.SelectedValue = "male";
            }
            if (user.Gender == "Female")
            {
                rdbtnGender.SelectedValue = "female";
            }


            aptxtFname.ReadOnly = true;
            aptxtLname.ReadOnly = true;
            rdbtnGender.Enabled = false;
            ucon.CloseConnection();
        }
        else
        {
            aptxtFname.ReadOnly = false;
            aptxtLname.ReadOnly = false;
            aptxtDob.ReadOnly = false;
            rdbtnGender.Enabled = true;
            aptxtFname.Text = "";
            aptxtLname.Text = "";
            aptxtDob.Text = "";

        }
    }

}