﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MainDllLibrary;
using System.Configuration;

public partial class User_User : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            UserConnection ucon = new UserConnection();
            ucon.OpenConnection(ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString);
            lblName.Text = "Welcome ";

            if (Session["uid"] != null)
            {
                string name = ucon.GetUserName(Session["uid"].ToString());
                if (name != null)
                {
                    lblName.Text += name;
                }
                else
                {
                    Response.Redirect("../Error.aspx");
                }
                
            }
            else
            {
                Response.Redirect("../Default.aspx");
            }
            ucon.CloseConnection();

          
    
        }
    }
}
