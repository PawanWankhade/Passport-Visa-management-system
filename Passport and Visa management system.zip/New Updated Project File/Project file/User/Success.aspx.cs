﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MainDllLibrary;

public partial class User_Success : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(Session["uid"]!=null || Session["uid"]!="")
        {
            if (Session["uid"] == null || Session["uid"] == "")
            {
                Response.Redirect("../Default.aspx");
            }
            
            if (!IsPostBack)
            {
                string type = Request.QueryString.Get("type");
                if (type == "visa")
                {
                    lblHeading.Text = "Visa Registration Successfull<br />";

                    
                    
                    lblDetailsTitle.Text = "Dear User your Visa request has been accepted successfully";
                    lblDetails.Text = "Visa ID &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + "<span style=\"Color:#2780e3;\">" + Request.QueryString["vid"] + "</span><br />";
                    lblDetails.Text += "User ID &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + "<span style=\"Color:#2780e3;\">" + Request.QueryString["uid"] + "</span><br />";
                    lblDetails.Text += "Destination &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + "<span style=\"Color:#2780e3;\">" + Request.QueryString["destination"] + "</span><br />";
                    lblDetails.Text += "Date of Application &nbsp;&nbsp;" + "<span style=\"Color:#2780e3;\">" + Request.QueryString["apply"] + "</span><br />";
                    lblDetails.Text += "Date of Issue &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + "<span style=\"Color:#2780e3;\">" + Request.QueryString["issue"] + "</span><br />";
                    lblDetails.Text += "Date of Expiry &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + "<span style=\"Color:#2780e3;\">" + Request.QueryString["expiry"] + "</span><br />";
                    lblDetails.Text += "Registration Cost &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + "<span style=\"Color:#2780e3;\">" + Request.QueryString["amount"] + "</span><br />";
                    lblDetails.Text += Request.QueryString[""] + "<br />";


                }
                if (type == "changePassword")
                {
                    lblHeading.Text = "Password changed Successfully";
                    if (Request.QueryString["msg"] == null)
                    {
                        HyperLink1.Visible = true;
                        Session["uid"] = null;
                        HyperLink1.Text = "Click here to login";
                        
                    }
                    else
                    {
                        lblDetailsTitle.Text = "Some Error occured";
                    }



                }

                if (type == "passportRegistration")
                {
                    lblHeading.Text = "Passport Registration Successfull";
                    lblDetailsTitle.Text = "Passport Details :";
                    lblDetails.Text = "Temporary ID &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;   " + "<span style=\"Color:#2780e3;\">" + Request.QueryString["pid"] + "</span><br />";
                    lblDetails.Text += "Issue Date &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;   " + "<span style=\"Color:#2780e3;\">" + Request.QueryString["issue"] + "</span><br />";
                    lblDetails.Text += "Expiry Date  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  " + "<span style=\"Color:#2780e3;\">" + Request.QueryString["expiry"] + "</span><br />";
                    lblDetails.Text += "Amount to be Paid &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + "<span style=\"Color:#2780e3;\">" + Request.QueryString["amount"] + "</span><br />";
                }

                if (type == "visaCancellation")
                {
                    lblHeading.Text = "Visa Cancellation";
                    lblDetailsTitle.Text = "Your request has been submitted successfully";
                    lblDetails.Text = "Please pay Rs. ";
                    lblDetails.Text += "<span style=\"Color:#2780e3;\">" + Request.QueryString["amount"] + "</span>";
                    lblDetails.Text += " to complete the cancellation process";
                }
            }
            else
            {
                Response.Redirect("../Default.aspx");
            }
            
        }
    }
}