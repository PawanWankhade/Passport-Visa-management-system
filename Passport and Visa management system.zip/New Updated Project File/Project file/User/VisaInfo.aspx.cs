﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MainDllLibrary;
using System.Configuration;

public partial class User_VisaInfo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Panel1.Visible = false;
        string uid = "";
        
        if (Session["uid"] == null || Session["uid"] == "")
        {
            Response.Redirect("../Default.aspx");
        }
        
        if (Session["uid"] != null || Session["uid"] != "")
        {
            uid = Session["uid"].ToString();
        }
        else
        {
            Response.Redirect("../Default.aspx");
        }
        
        List<string> list = new List<string>();
        if (!IsPostBack)
        {
            VisaConnect pcon = new VisaConnect();
            pcon.OpenConnection(ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString);
            list = pcon.GetAllVisaId(uid);

            foreach (string s in list)
            {
                DropDownList1.Items.Add(s);
            }

            pcon.CloseConnection();
        }
        
    }
  
    protected void btnSave_Click(object sender, EventArgs e)
    {
        Panel1.Visible = true;
        string pid = DropDownList1.SelectedItem.Text;
        VisaConnect pcon = new VisaConnect();
        pcon.OpenConnection(ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString);
        string uid = "";
        if (Session["uid"] != null || Session["uid"] != "")
        {
            uid = Session["uid"].ToString();
        }
        else
        {
            Response.Redirect("../Default.aspx");
        }
        Visa p = pcon.GetVisaByID(pid, uid);


        txtPid.Text = p.PID;
        txtDestination.Text = p.Country;
        txtApply.Text = p.ApplyDate.ToString();
        txtIssue.Text = p.IssueDate.ToString();
        txtExpiry.Text = p.ExpiryDate.ToString();
        txtAmount.Text = p.Amount.ToString();


        pcon.CloseConnection();
    }
    protected void btnCancle_Click(object sender, EventArgs e)
    {
        Response.Redirect("WelcomeUser.aspx");
    }
}