﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MainDllLibrary;
using System.Configuration;

public partial class User_PassportInfo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["uid"] == null || Session["uid"] == "")
        {
            Response.Redirect("../Default.aspx");
        }
        
        
        Panel1.Visible = false;
        string uid = "";
        List<string> list = new List<string>();
        if(Session["uid"]!=null || Session["uid"]!="")
        {
            uid = Session["uid"].ToString();
        }
        else
        {
            Response.Redirect("../Default.aspx");
        }
        if (!IsPostBack)
        {
            PassportConnect pcon = new PassportConnect();
            pcon.OpenConnection(ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString);
            list = pcon.GetAllPassportId(uid);

            foreach (string s in list)
            {
                DropDownList1.Items.Add(s);
            }
            
            pcon.CloseConnection();
        }
        
        
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
       
    }
   
    protected void btnSave_Click(object sender, EventArgs e)
    {
        Panel1.Visible = true;
        string pid = DropDownList1.SelectedItem.Text;
        PassportConnect pcon = new PassportConnect();
        pcon.OpenConnection(ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString);
        string uid = "";
        if (Session["uid"] != null || Session["uid"] != "")
        {
            uid = Session["uid"].ToString();
        }
        else
        {
            Response.Redirect("../Default.aspx");
        }
        Passport p = pcon.GetPassportByPid(pid, uid);

        txtApply.Text = p.ApplyDate.ToString();
        txtDob.Text = p.Dob.ToString();
        txtExpiry.Text = p.ExpiryDate.ToString();
        txtFname.Text = p.Fname.ToString();
        txtLname.Text = p.Lname.ToString();

        txtIssue.Text = p.IssueDate.ToString();
        txtIdentity.Text = p.Identity.ToString();

       

        pcon.CloseConnection();
    }

    protected void btnCancle_Click(object sender, EventArgs e)
    {
        Response.Redirect("WelcomeUser.aspx");
    }
}