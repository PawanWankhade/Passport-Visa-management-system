﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MainDllLibrary;
using System.Configuration;

public partial class User_ChangeUserPassword : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["uid"] == null || Session["uid"] == "")
        {
            Response.Redirect("../Default.aspx");
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Credentials c = new Credentials();
        if (Session["uid"] == null || Session["uid"] == "")
        {
            Response.Redirect("../Default.aspx");
        }
        else
        {
            c.uid = Session["uid"].ToString();
        }
        c.password = txtOld.Text;
        bool flag = true;
        bool changePasswordFlag = false;
        UserConnection ucon = new UserConnection();
        ucon.OpenConnection(ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString);

        flag = ucon.ValidateUser(c);
        if (flag)
        {
            c.password = txtNew.Text;
            changePasswordFlag = ucon.ChangePassword(c);
            if (changePasswordFlag)
            {
                Response.Redirect("Success.aspx?type=changePassword");
            }
            else
            {
                Response.Redirect("Success.aspx?type=changePassword&msg=error");
            }

        }
        else
        {
            lblError.Text = "Please check old password";
            lblError.ForeColor = System.Drawing.Color.Red;
            txtOld.Focus();
        }


        ucon.CloseConnection();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("WelcomeUser.aspx");
    }
}