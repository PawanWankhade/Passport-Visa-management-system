﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MainDllLibrary;
using System.Configuration;
using System.Data;

public partial class User_Apply_Visa : System.Web.UI.Page
{
    Passport p = new Passport();
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["uid"] == null || Session["uid"] == "")
        {
            Response.Redirect("../Default.aspx");
        }
        Panel1.Visible = false;

    }
    protected void btnSave_Click(object sender, EventArgs e)
    {

        PassportConnect pc = new PassportConnect();
        pc.OpenConnection(ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString);

        if (Session["uid"] != null)
        {

            p = pc.GetPassportByPid(txtPassport.Text, Session["uid"].ToString());
            if (p.PID != null)
            {
                Label1.Text = "";
                Session["pid"] = p.PID;
                Panel1.Visible = true;
                txtUid.Text = p.Uid;
                GenerateFields fields = new GenerateFields();
                fields.OpenConnection(ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString);
                DataSet ds = fields.GetCountries();
                ddlCountry.DataSource = ds;
                ddlCountry.DataTextField = ds.Tables[0].Columns[1].ToString();
                ddlCountry.DataValueField = ds.Tables[0].Columns[0].ToString();
                ddlCountry.DataBind();
                fields.CloseConnection();

                fields = new GenerateFields();
                fields.OpenConnection(ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString);
                ds = fields.GetOccupation();
                ddlOccupation.DataSource = ds;
                ddlOccupation.DataTextField = ds.Tables[0].Columns[0].ToString();

                ddlOccupation.DataBind();

                fields.CloseConnection();

            }
            else
            {
                Label1.Text = "Passport ID does not exist";
                Label1.ForeColor = System.Drawing.Color.Red;
                txtPassport.Focus();
            }
        }
        else
        {
            Response.Redirect("../Error.aspx?name=expire");
        }
        pc.CloseConnection();


    }

    protected void btnSubmit2_Click(object sender, EventArgs e)
    {
        Visa visa = new Visa();
        visa.Country = ddlCountry.SelectedItem.Text;
        visa.Occupation = ddlOccupation.SelectedItem.Text;
        visa.ApplyDate = DateTime.Now;
        visa.IssueDate = (DateTime.Now).AddDays(10);
        visa.ExpiryDate = (DateTime.Now).AddYears(10);

        if (Session["uid"] != null || Session["uid"] != "")
        {
            visa.Uid = Session["uid"].ToString();

        }
        else
        {
            Response.Redirect("../Default.aspx");
        }
        if (Session["pid"] != null)
        {
            visa.PID = Session["pid"].ToString();
            Session["pid"] = null;
        }
        else
        {
            Response.Redirect("../Error.aspx?type=expire");
        }

        VisaConnect connect = new VisaConnect();
        connect.OpenConnection(ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString);
        Visa credits = new Visa();
        if (Session["uid"] != null)
        {
            credits = connect.InsertVisa(visa);
        }
        else
        {
            Label1.Text = "session is empty";
        }
        if (credits.VID != null)
        {
            Response.Redirect("Success.aspx?type=visa&amount=" + credits.Amount + "&expiry=" + credits.ExpiryDate + "&vid=" + credits.VID + "&occupation=" + credits.Occupation + "&issue=" + credits.IssueDate + "&apply=" + credits.ApplyDate + "&destination=" + credits.Country + "&uid=" + credits.Uid);
        }
        else
        {
            Response.Write("../Error.aspx");
        }

        connect.CloseConnection();
    }
    protected void btnCancle_Click(object sender, EventArgs e)
    {
        Response.Redirect("WelcomeUser.aspx");
    }
    protected void btnCancle2_Click(object sender, EventArgs e)
    {
        Response.Redirect("WelcomeUser.aspx");
    }
}