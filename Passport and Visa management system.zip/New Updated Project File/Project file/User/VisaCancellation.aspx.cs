﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MainDllLibrary;
using System.Configuration;

public partial class User_VisaCancellation : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["uid"] == null || Session["uid"] == "")
        {
            Response.Redirect("../Default.aspx");
        }
        if (!IsPostBack)
        {
            Panel1.Visible = true;
            Panel2.Visible = false;
            
            if (Session["uid"] != null)
            {
                vctxtUserid.Text = Session["uid"].ToString();
            }
            else
            {
                Response.Redirect("../Default.aspx");
            }
        
        }
    }
    protected void vcbtnSubmit_Click(object sender, EventArgs e)
    {
        User user = new User();
        user.Uid = vctxtUserid.Text;
        user.Question = vcdropHint.SelectedItem.Text;
        user.Answer = vctxtHintans.Text;
        user.Email = vctxtEmail.Text;

        UserConnection ucon = new UserConnection();
        ucon.OpenConnection(ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString);

        bool flag = ucon.ValidateUserDetails(user);

        if (flag)
        {
            Panel1.Visible = false;
            Panel2.Visible = true;
            if (Session["uid"] != null)
            {
                vc2txtUserid.Text = Session["uid"].ToString();
            }
            else
            {
                Response.Redirect("../Default.aspx");
            }

        }
        else
        {
            Label2.Text = "Please check credentials";
            Label2.ForeColor = System.Drawing.Color.Red;
            
        }

        ucon.CloseConnection();
    }
    protected void vc2btnSubmit_Click(object sender, EventArgs e)
    {
        Visa visa = new Visa();
        visa.VID = vc2txtvisaid.Text;
        visa.PID = vc2txtpassportid.Text;
      //  visa.IssueDate = Convert.ToDateTime(vc2txtissuedate.Text);
        if (Session["uid"] != null)
        {
            visa.Uid = Session["uid"].ToString();
        }
        else
        {
            Response.Redirect("../Default.aspx");
        }

        VisaConnect vconnect = new VisaConnect();
        vconnect.OpenConnection(ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString);
      
        bool validateFlag = vconnect.ValidateVisa(visa);
        
        if (validateFlag)
        {
            double updateFlag = vconnect.CancleVisa(visa.VID, visa.Uid);
            if (updateFlag > 0)
            {
                lblVisa.Text = "Visa Cancelled Successfully";
                Response.Redirect("Success.aspx?type=visaCancellation&amount="+updateFlag);

                lblVisa.ForeColor = System.Drawing.Color.Green;
            }
            if(updateFlag == -1)
            {
                //Visa not found
                Response.Redirect("../Error.aspx");    
            }
            if (updateFlag == -2)
            {
                //Exception Occurs

                Response.Redirect("../Error.aspx");
            }
                
            
            
        }
        else
        {
            lblVisa.Text = "Visa record not found";
            lblVisa.ForeColor = System.Drawing.Color.Red;
        }
        
        vconnect.CloseConnection();
    }
    protected void vc2btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("WelcomeUser.aspx");
    }
    protected void vcbtnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("WelcomeUser.aspx");
    }
}