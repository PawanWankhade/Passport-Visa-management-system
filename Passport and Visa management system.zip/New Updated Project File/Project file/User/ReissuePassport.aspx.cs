﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using MainDllLibrary;

public partial class User_ReissuePassport : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["uid"] == null || Session["uid"] == "")
        {
            Response.Redirect("../Default.aspx");
        }
        
        if (!IsPostBack)
        {

            if (Session["uid"] == null || Session["uid"] == "")
            {
                Response.Redirect("../Default.aspx");
            }

            rptxtuid.Text = Session["uid"].ToString().ToUpper();
            GenerateFields generate = new GenerateFields();
            string s = ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString;


            generate.OpenConnection(s);
            DataSet ds = generate.GetStates();
            rpddlState.DataSource = ds;
            rpddlState.DataTextField = ds.Tables[0].Columns[1].ToString();
            rpddlState.DataValueField = ds.Tables[0].Columns[0].ToString();

            rpddlState.DataBind();

            ds = generate.GetCities("S_A001");
            rpddlcity.DataSource = ds;
            rpddlcity.DataTextField = ds.Tables["cities"].Columns[1].ToString();
            rpddlcity.DataBind();

            generate.CloseConnection();

            rptxtissuedate.Text = DateTime.Now.Date.ToString().Substring(0, 9);
        }
    }


    protected void rpbtnSave_Click1(object sender, EventArgs e)
    {
        string id = rpddlState.SelectedItem.Value;
      

        string s = ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString;
        GenerateFields generate = new GenerateFields();
        generate.OpenConnection(s);
        DataSet ds = generate.GetCities(id);
       
        rpddlcity.DataSource = ds;
        rpddlcity.DataTextField = ds.Tables["cities"].Columns[1].ToString();
        rpddlcity.DataBind();
        generate.CloseConnection();

   }
    protected void rpbtnSave_Click(object sender, EventArgs e)
    {
        bool flag = false;
        string pid, uid, reason;
        pid = rptxtpassid.Text;
        uid = rptxtuid.Text;
        reason = rpddlreason.SelectedItem.Text;
        string s = ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString;
        PassportConnect pc = new PassportConnect();
        pc.OpenConnection(s);

        Passport p = pc.GetPassportByPid(pid, uid);
        if (p.PID != null)
        {
            flag = pc.PassportHistory(p, reason);
            
            if (flag == true)
            {
                //  Response.Write("success");
                Passport newPassport = p;
                newPassport.Pin = Convert.ToInt32(rptxtpin.Text);
                newPassport.State = rpddlcity.SelectedItem.Text;
                newPassport.Country = rpddlCountry.SelectedItem.Text;
                newPassport.TypeofService = rprdtypeofservice.SelectedItem.Text;
                newPassport.ApplyDate = Convert.ToDateTime((rptxtissuedate.Text));
                newPassport.BookletType = Convert.ToInt32(rprdbooklettype.SelectedItem.Value);
                newPassport.City = rpddlcity.SelectedItem.Text;
                if (Session["uid"] != null || Session["uid"] != "")
                {
                    newPassport.Uid = Session["uid"].ToString();
                }
                else
                {
                    Response.Redirect("../Default.aspx");
                }
                Passport newCredits = pc.InsertPassport(newPassport);

                if (newCredits.PID != "")
                {
                    bool updateFlag = pc.UpdatePassport(pid,uid);
                    if (updateFlag)
                    {
                        Response.Redirect("Success.aspx?type=passportRegistration&pid=" + newCredits.PID + "&amount=" + newCredits.Amount + "&expiry=" + newCredits.ExpiryDate+"&issue="+newCredits.IssueDate);
                    }
                    else
                    {
                        Response.Redirect("../Error.aspx");
                    }
                }
                else
                {

                    Response.Redirect("../Error.aspx");
                }


            }

            else
            { 
            
            }
            
        }
        else
        {
            lblError.Text = "Passport does not exist";
            lblError.ForeColor = System.Drawing.Color.Red;
            rptxtpassid.Focus();
        }
        
        pc.CloseConnection();

    }
    protected void rpbtnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("WelcomeUser.aspx");
    }
}