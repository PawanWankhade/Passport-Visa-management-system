﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace MainDllLibrary
{
    public class Visa
    {
        public string VID { get; set; }
        public string PID { get; set; }
        public string Occupation { get; set; }
        public string Uid { get; set; }
        public string Country { get; set; }
        public DateTime IssueDate { get; set; }
        public DateTime ExpiryDate { get; set; }
        public DateTime ApplyDate { get; set; }
        public int Amount { get; set; }

        public Visa()
        { }

    }

    //This class handles all Visa related activities
    public class VisaConnect
    {
      
        SqlConnection scon = new SqlConnection();
        public VisaConnect()
        { }


        //to open sql connection
        public void OpenConnection(string con)
        {
            scon.ConnectionString = con;
            scon.Open();
        }

        //to close sql connection
        public void CloseConnection()
        {
            scon.Close();
        }


        //to insert values in database when user applies for visa
        public Visa InsertVisa(Visa visa)
        {
           
            DataSet ds = new DataSet();
            string temp = "";

            try
            {
            using (SqlDataAdapter sda = new SqlDataAdapter("select top 1 vid from visa_details where occupation like '"+visa.Occupation+"%' order by vid desc",scon))
            {
                sda.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    temp = ds.Tables[0].Rows[0]["vid"].ToString();
                }
                else
                {
                    temp = "";
                }
            }


                //to generate visa id

            if (temp == "" || temp == null)
            {
                switch (visa.Occupation)
                {
                    case "Student": temp = "ST-0001";
                        break;
                    case "Self Employee": temp = "SE-0001";
                        break;
                    case "Government Employee": temp = "GE-0001";
                        break;
                    case "Private Employee": temp = "PE-0001";
                        break;
                    case "Retired Employee": temp = "RE-0001";
                        break;

                    default: temp = "AA-0001";
                        break;

                }

                visa.VID = temp;
            }


            else
            {
                string oldID = temp.Substring(3);
                int num = Convert.ToInt32(oldID);
                switch (visa.Occupation)
                {
                    case "Student": num = num + 1;
                        temp = "ST-" + num.ToString().PadLeft(4, '0');
                        break;

                    case "Self Employee": num = num + 1;
                        temp = "SE-" + num.ToString().PadLeft(4, '0');
                        break;

                    case "Government Employee": num = num + 1;
                        temp = "GE-" + num.ToString().PadLeft(4, '0');
                        break;

                    case "Private Employee": num = num + 1;
                        temp = "PE-" + num.ToString().PadLeft(4, '0');
                        break;

                    case "Retired Employee": num = num + 1;
                        temp = "RE-" + num.ToString().PadLeft(4, '0');
                        break;
                    default: num = num + 1;
                        temp = "AA-" + num.ToString().PadLeft(4, '0');
                        break;
                }


               visa.VID = temp;


            }

           //to retrieve amount from database based on occupation and country
            using (SqlDataAdapter sda2 = new SqlDataAdapter("select * from occupation where occname like '"+visa.Occupation+"%' and place='"+visa.Country+"'",scon))
            {
                DataSet ds2 = new DataSet();
                sda2.Fill(ds2);
                
                if (ds2.Tables[0].Rows.Count > 0)
                {
                    visa.Amount = Convert.ToInt32(ds2.Tables[0].Rows[0]["amount"]);
                }
                else
                {
                    visa.Amount = 50;
                }
                
            }
            

            //insert values in visa_details
            string sql = string.Format("insert into visa_details(vid,pid,uid,destination,occupation,applydate,issuedate,expirydate,cost) values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}',{8})",visa.VID,visa.PID,visa.Uid,visa.Country,visa.Occupation,visa.ApplyDate,visa.IssueDate,visa.ExpiryDate,visa.Amount);
            using (SqlDataAdapter sda = new SqlDataAdapter(sql,scon))
            { 
                sda.Fill(ds,"insertVisa");

            }
            }
            catch(Exception)
            {
                visa.VID = "";
            }
          
            return visa;
        }



        //to get all visa of an active user based on user id

        public List<string> GetAllVisaId(string uid)
        {
            List<string> list = new List<string>();
            using (SqlDataAdapter sda = new SqlDataAdapter("select vid from visa_details where uid = '" + uid + "' and status = 'active'", scon))
            {
                DataSet ds = new DataSet();
                sda.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        string s = ds.Tables[0].Rows[i]["vid"].ToString();
                        list.Add(s);
                    }
                }


            }
            return list;
        }


        //to get visa details based on visa id and user id
        public Visa GetVisaByID(string vid,string uid)
        {
            Visa v = new Visa();
            DataSet ds = new DataSet();

            string sql = "select * from visa_details where vid= '" + vid + "' and uid= '" + uid + "'";

            using (SqlDataAdapter sda = new SqlDataAdapter(sql, scon))
            {

                sda.Fill(ds, "Visa");
                if (ds.Tables[0].Rows.Count > 0)
                {
                    v.VID = ds.Tables["Visa"].Rows[0]["vid"].ToString();
                    v.PID = ds.Tables["Visa"].Rows[0]["pid"].ToString();
                    v.Occupation = ds.Tables["Visa"].Rows[0]["occupation"].ToString();
                    v.Uid = ds.Tables["Visa"].Rows[0]["uid"].ToString();
                    v.Country = ds.Tables["Visa"].Rows[0]["destination"].ToString();
                    v.IssueDate = Convert.ToDateTime(ds.Tables["Visa"].Rows[0]["issuedate"]);
                    v.ExpiryDate = Convert.ToDateTime(ds.Tables["Visa"].Rows[0]["expirydate"]);
                    v.ApplyDate = Convert.ToDateTime(ds.Tables["Visa"].Rows[0]["applydate"]);
                    v.Amount = Convert.ToInt32(ds.Tables["Visa"].Rows[0]["cost"]);
                    v.Country = ds.Tables[0].Rows[0]["destination"].ToString();

                }
                else
                {
                    v.VID = "";
                }

                return v;
            }


        }

        // to insert values in visa_history when user applies for visa cancellation
        public bool VisaHistory(Visa v)
        {
            bool flag = true;
            string sql = string.Format("insert into visa_history " +
                                       "(uid,old_vid,pid,destination,occupation,applydate,issuedate,expirydate,cost) " +
                                          "values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}',{8})", v.Uid, v.VID, v.PID, v.Country, v.Occupation, v.ApplyDate, v.IssueDate, v.ExpiryDate, v.Amount);


            try
            {
                using (SqlDataAdapter sda = new SqlDataAdapter(sql, scon))
                {
                    DataSet ds = new DataSet();
                    sda.Fill(ds, "InsertVisaHistory");
                    flag = true;
                }
            }
            catch (Exception)
            {
                flag = false;
            }

            return flag;
        }

        //to calculate amount to be paid for visa cancellation

        public double AmountCal(Visa v)
        {

            double month = ((v.ExpiryDate - DateTime.Now).Days) / 30;
            double amountPaid=0;
            switch (v.Occupation)
            {
                case "Student":
                    if (month < 6)
                    {
                        amountPaid = v.Amount * .15;
                    }
                    else
                        amountPaid = v.Amount * .25;
                    break;

                case "Self Employee":
                    if (month < 6)
                    {
                        amountPaid = v.Amount * .15;
                    }
                    else
                        amountPaid = v.Amount * .25;

                    break;

                case "Government Employee":
                    if (month < 6)
                    {
                        amountPaid = v.Amount * .12;
                    }
                    else if (month >= 6 && month < 12)
                        amountPaid = v.Amount * .20;
                    else
                        amountPaid = v.Amount * .25;
                    break;

                case "Private Employee":
                    if (month < 6)
                    {
                        amountPaid = v.Amount * .15;
                    }
                    else if (month >= 6 && month < 12)
                        amountPaid = v.Amount * .25;
                    else
                        amountPaid = v.Amount * .20;

                    break;

                case "Retired Employee":
                    if (month < 6)
                    {
                        amountPaid = v.Amount * .10;
                    }
                    else
                        amountPaid = v.Amount * .20;

                    break;
                default:

                    amountPaid = 0;
                    break;
            }

            return amountPaid;
        }
        

       


        //to check for a particular user that visa exist or not
        public bool ValidateVisa(Visa v)
        {
            bool flag;

            string sql = "select * from visa_details where vid = '"+v.VID+"' and uid = '"+v.Uid+"' and pid = '"+v.PID+"' and [status] = 'active'";
            try
            {
                using (SqlDataAdapter sda = new SqlDataAdapter(sql, scon))
                {
                    DataSet ds = new DataSet();
                    sda.Fill(ds, "Visa");
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        flag = true;
                    }
                    else
                    {
                        flag = false;
                    }
                }
            }
            catch (Exception)
            {
                flag = false; 
            }
            return flag;
        
        }

        //to update visa status when user applies for visa cancellation
        public bool UpdateVisa(string vid, string uid)
        {
            bool flag = true;
            string sql = "update visa_details set status = 'cancelled' where vid = '" + vid + "' and uid = '" + uid + "'";
            try
            {
                using (SqlDataAdapter sda = new SqlDataAdapter(sql, scon))
                {
                    DataSet ds = new DataSet();
                    sda.Fill(ds);
                    flag = true;
                }
            }
            catch (Exception)
            {
                flag = false;
                
            }

            return flag;
        }

        //visa cancellation
        public double CancleVisa(string vid,string uid)
        {
            double amount = 0;
            bool updateVisaFlag = false;
            try
            {
                Visa visa = GetVisaByID(vid, uid);
                if (visa.VID != null)
                {
                    //first, insert records in visa_history table
                    bool visaHistoryFlag = VisaHistory(visa);
                    if (visaHistoryFlag)
                    {
                        amount = AmountCal(visa);
                        if (amount > 0)
                        {
                            //update status in visa_details
                            updateVisaFlag = UpdateVisa(vid, uid);
                        }
                    }
                    else
                    {
                        
                        amount = 0;
                    }
                }
                else
                {
                    
                    amount = -1;
                }
            }
            catch (Exception)
            {
               
                amount = -2;
            }

            if (!updateVisaFlag)
            {
                amount = 0;
            }
            return amount;
        }
    
    
    }


    
}
