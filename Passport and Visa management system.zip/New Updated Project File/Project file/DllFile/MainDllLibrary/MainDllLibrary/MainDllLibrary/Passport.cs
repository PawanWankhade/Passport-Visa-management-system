﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace MainDllLibrary
{
    public class Passport
    {
        public string Fname { get; set; }
        public string Lname { get; set; }
        public string Uid { get; set; }
        public DateTime Dob { get; set; }
        public string Country { get; set; }
        public string State { get; set; }
        public string City { get; set; }
        public int Pin { get; set; }
        public string Gender { get; set; }
        public string Marital { get; set; }

        public string Qualification { get; set; }
        public string TypeofService { get; set; }
        public DateTime ApplyDate { get; set; }
        public DateTime IssueDate { get; set; }
        public int BookletType { get; set; }
        public DateTime ExpiryDate { get; set; }
        public string Identity { get; set; }
        public string PID { get; set; }
        public int Amount { get; set; }



        public Passport()
        { }

    }

    //This class handles all Passport related activities
    public class PassportConnect
    {
        SqlConnection scon;
        public PassportConnect()
        {

        }

        //to open sql connection
        public void OpenConnection(string con)
        {
            scon = new SqlConnection(con);
            scon.Open();
        }

        //to close sql connection
        public void CloseConnection()
        {
            scon.Close();
        }

        //to insert passport details in database
        public Passport InsertPassport(Passport p)
        {
            DataSet ds = new DataSet();
            if (p.BookletType == 30)
            {

                using (SqlDataAdapter sda = new SqlDataAdapter("select top 1 pid from passport_details where booklettype like '30' order by pid desc", scon))
                {
                    sda.Fill(ds);
                }
                string temp = "";
                if (ds.Tables[0].Rows.Count > 0)
                {
                    temp = ds.Tables[0].Rows[0]["pid"].ToString();
                }

                //to generate temporary id
                if (temp == "" || temp == null)
                {
                    p.PID = "FPS-300001";
                }
                else
                {

                    int id = (Convert.ToInt32(temp.Substring(4, 6))) + 1;
                    p.PID = "FPS-" + id.ToString();
                }
            }
            else
            {
                if (p.BookletType == 60)
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter("select top 1 pid from passport_details where booklettype like '60' order by pid desc", scon))
                    {
                        sda.Fill(ds);
                    }
                    string temp = "";
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        temp = ds.Tables[0].Rows[0]["pid"].ToString();
                    }

                    if (temp == "" || temp == null)
                    {
                        p.PID = "FPS-600001";
                    }
                    else
                    {
                        int id = (Convert.ToInt32(temp.Substring(4, 6))) + 1;
                        p.PID = "FPS-" + id.ToString();
                    }
                }

            }


            if (p.TypeofService == "Normal")
            {
                p.Amount = 2500;
            }
            else
            {
                p.Amount = 5000;
            }

            //insertion in database

            string sql = string.Format("insert into passport_details " +
                                        "(pid,uid,fname,lname,dateofbirth,country,state,city,pin,gender,maritalstatus,qualification,typeofservice,applydate,issuedate,booklettype,cost,expirydate,[identity]) " +
                                           "values('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}',{8},'{9}','{10}','{11}','{12}','{13}','{14}',{15},{16},'{17}','{18}')", p.PID, p.Uid, p.Fname, p.Lname, p.Dob, p.Country, p.State, p.City, p.Pin, p.Gender, p.Marital, p.Qualification, p.TypeofService, p.ApplyDate, p.IssueDate, p.BookletType, p.Amount, p.ExpiryDate, p.Identity);

            try
            {
                using (SqlDataAdapter sda = new SqlDataAdapter(sql, scon))
                {
                    sda.Fill(ds, "InsertPassport");
                }
            }
            catch (Exception)
            {
                p.PID = "";
            }
            return p;
        }




        //to maintain records in passport_history table when user reissues his passport
        public bool PassportHistory(Passport p, string reason)
        {
            bool flag = false;
            string sql = string.Format("insert into passport_history " +
                                        "(uid,old_pid,reason,country,state,city,pin,typeofservice,applydate,issuedate,booklettype,cost) " +
                                           "values('{0}','{1}','{2}','{3}','{4}','{5}',{6},'{7}','{8}','{9}',{10},{11})", p.Uid, p.PID, reason, p.Country, p.State, p.City, p.Pin, p.TypeofService, p.ApplyDate, p.IssueDate, p.BookletType, p.Amount);


            try
            {
                using (SqlDataAdapter sda = new SqlDataAdapter(sql, scon))
                {
                    DataSet ds = new DataSet();
                    sda.Fill(ds, "InsertPassportHistory");
                    flag = true;
                }
            }
            catch (Exception)
            {
                flag = false;
            }
            return flag;

        }


        //to retrieve passport details of user with the help of his user id
        public List<Passport> GetPassportDetails(string uid)
        {
            Passport p = new Passport();
            List<Passport> list = new List<Passport>();
            DataSet ds = new DataSet();

            string sql = "select pid,fname,typeofservice,booklettype,applydate,issuedate,expirydate from passport_details where uid='" + uid + "'";

            using (SqlDataAdapter sda = new SqlDataAdapter(sql, scon))
            {

                sda.Fill(ds, "Passport");

                if (ds.Tables[0].Rows.Count > 0)
                {

                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {

                        p = new Passport();
                        p.PID = ds.Tables["Passport"].Rows[i]["pid"].ToString();
                        p.Fname = ds.Tables["Passport"].Rows[i]["fname"].ToString();
                        p.TypeofService = ds.Tables["Passport"].Rows[i]["typeofservice"].ToString();
                        p.Lname = ds.Tables["Passport"].Rows[i]["lname"].ToString();
                        p.Dob = Convert.ToDateTime(ds.Tables["Passport"].Rows[i]["dateofbirth"]);
                        p.Country = ds.Tables["Passport"].Rows[i]["country"].ToString();
                        p.State = ds.Tables["Passport"].Rows[i]["state"].ToString();
                        p.City = ds.Tables["Passport"].Rows[i]["city"].ToString();
                        p.Pin = Convert.ToInt32(ds.Tables["Passport"].Rows[i]["pin"]);
                        p.Gender = ds.Tables["Passport"].Rows[i]["gender"].ToString();
                        p.Marital = ds.Tables["Passport"].Rows[i]["maritalstatus"].ToString();

                        p.Qualification = ds.Tables["Passport"].Rows[i]["qualification"].ToString();

                        p.ApplyDate = Convert.ToDateTime(ds.Tables["Passport"].Rows[i]["applydate"]);
                        p.IssueDate = Convert.ToDateTime(ds.Tables["Passport"].Rows[i]["issuedate"]);
                        p.BookletType = Convert.ToInt32(ds.Tables["Passport"].Rows[i]["booklettype"]);
                        p.ExpiryDate = Convert.ToDateTime(ds.Tables["Passport"].Rows[i]["expirydate"]);
                        p.Amount = Convert.ToInt32(ds.Tables["Passport"].Rows[i]["cost"]);
                        p.Identity = ds.Tables["Passport"].Rows[i]["identity"].ToString();


                        list.Add(p);
                    }
                }
                else
                {

                }
            }


            return list;
        }

        //to get passport details of  active user with his user id and temporary id
        public Passport GetPassportByPid(string pid, string uid)
        {
            Passport p = new Passport();
            DataSet ds = new DataSet();
            string sql = "select * from passport_details where pid = '" + pid + "' and uid = '" + uid + "' and [status] = 'active'";
            using (SqlDataAdapter sda = new SqlDataAdapter(sql, scon))
            {

                sda.Fill(ds, "Passport");
                if (ds.Tables[0].Rows.Count > 0)
                {
                    p.Fname = ds.Tables["Passport"].Rows[0]["fname"].ToString();
                    p.Lname = ds.Tables["Passport"].Rows[0]["lname"].ToString();
                    p.Dob = Convert.ToDateTime(ds.Tables["Passport"].Rows[0]["dateofbirth"]);
                    p.Country = ds.Tables["Passport"].Rows[0]["country"].ToString();
                    p.State = ds.Tables["Passport"].Rows[0]["state"].ToString();
                    p.City = ds.Tables["Passport"].Rows[0]["city"].ToString();
                    p.Pin = Convert.ToInt32(ds.Tables["Passport"].Rows[0]["pin"]);
                    p.Gender = ds.Tables["Passport"].Rows[0]["gender"].ToString();
                    p.Marital = ds.Tables["Passport"].Rows[0]["maritalstatus"].ToString();

                    p.Qualification = ds.Tables["Passport"].Rows[0]["qualification"].ToString();
                    p.TypeofService = ds.Tables["Passport"].Rows[0]["typeofservice"].ToString();
                    p.ApplyDate = Convert.ToDateTime(ds.Tables["Passport"].Rows[0]["applydate"]);
                    p.IssueDate = Convert.ToDateTime(ds.Tables["Passport"].Rows[0]["issuedate"]);
                    p.BookletType = Convert.ToInt32(ds.Tables["Passport"].Rows[0]["booklettype"]);
                    p.ExpiryDate = Convert.ToDateTime(ds.Tables["Passport"].Rows[0]["expirydate"]);
                    p.Identity = ds.Tables["Passport"].Rows[0]["identity"].ToString();
                    p.PID = ds.Tables["Passport"].Rows[0]["pid"].ToString();
                    p.Uid = ds.Tables["Passport"].Rows[0]["uid"].ToString();
                    p.Amount = Convert.ToInt32(ds.Tables["Passport"].Rows[0]["cost"].ToString());
                }

            }
            return p;
        }

        //to update user's status when he applies for reissue of passport
        public bool UpdatePassport(string pid, string uid)
        {
            bool flag = true;
            string sql = "update passport_details set [status] = 'expired' where pid='" + pid + "' and uid='" + uid + "'";
            try
            {
                using (SqlDataAdapter sda = new SqlDataAdapter(sql, scon))
                {
                    DataSet ds = new DataSet();
                    sda.Fill(ds, "Update_Passport");

                }
            }
            catch (Exception)
            {
                flag = false;
            }
            return flag;
        }


        //to retrieve all passport details of a user
        public List<string> GetAllPassportId(string uid)
        {
            List<string> list = new List<string>();
            using (SqlDataAdapter sda = new SqlDataAdapter("select pid from passport_details where uid = '" + uid + "' and status = 'active'", scon))
            {
                DataSet ds = new DataSet();
                sda.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        string s = ds.Tables[0].Rows[i]["pid"].ToString();
                        list.Add(s);
                    }
                }


            }
            return list;
        }

    }
}
