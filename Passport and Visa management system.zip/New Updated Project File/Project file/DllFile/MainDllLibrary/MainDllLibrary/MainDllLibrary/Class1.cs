﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Web.Security;



namespace MainDllLibrary
{
    public class User
    {
        public string Uid { get; set; }
        public string Fname { get; set; }
        public string Lname { get; set; }
        public DateTime Dob { get; set; }
        public string Gender { get; set; }
        public string Email { get; set; }
        public string Contact { get; set; }
        public string Address { get; set; }
        public string Qualification { get; set; }

        public string Question { get; set; }
        public string Answer { get; set; }

        public User()
        { }
    }

    public class Credentials
    {
        public string uid = "";
        public string password = "";
        public Credentials()
        {

        }


        //to gererate new user ID and password
        public Credentials GenerateCredentials(string uid)
        {
            Credentials c = new Credentials();
            string suid = uid;

            //to generate user ID for very first entry
            if (suid == "")
            {
                c.uid = "PASS-" + "0001";
            }

            else
            {

                int iuid = Convert.ToInt32(suid.Substring(5));

                iuid = iuid + 1;
                c.uid = "PASS-" + iuid.ToString().PadLeft(4, '0');
            }


            //to generate password

            var SpecialChar = "@#$";
            var selectedChar = new char[1];


            var ranChar = new Random();
            selectedChar[0] = SpecialChar[ranChar.Next(SpecialChar.Length)];

            var finalChar = new String(selectedChar);

            Random r = new Random();
            int i = r.Next(100, 1000);
            string spwd = DateTime.Now.Day.ToString() + DateTime.Now.ToString("MMM").ToLower() + finalChar + i.ToString();

            c.password = spwd;

            return c;
        }


        //to generate password when user forgot his password
        public Credentials NewPassword()
        {
            Credentials c = new Credentials();
            var SpecialChar = "@#$";
            var selectedChar = new char[1];


            var ranChar = new Random();
            selectedChar[0] = SpecialChar[ranChar.Next(SpecialChar.Length)];

            var finalChar = new String(selectedChar);

            Random r = new Random();
            int i = r.Next(100, 1000);
            string spwd = DateTime.Now.Day.ToString() + DateTime.Now.ToString("MMM").ToLower() + finalChar + i.ToString();

            c.password = spwd;

            return c;


        }



    }

    //This class handles all user related activities
    public class UserConnection
    {

        SqlConnection scon;

        public UserConnection()
        {

        }

        //to open sql connection
        public void OpenConnection(string con)
        {
            scon = new SqlConnection(con);
            scon.Open();
        }


        //to close sql connection
        public void CloseConnection()
        {
            scon.Close();
        }

        //Function to Digest Password using SHA1

        public string EncryptPassword(string pass)
        {
            string hash = "";
            hash = FormsAuthentication.HashPasswordForStoringInConfigFile(pass, "SHA1");
            return hash;
        }



        //to get user name who is logged in
        public string GetUserName(string uid)
        {
            string name = "";
            
            //calling GetUserNameByID procedure

            using (SqlCommand scmd = new SqlCommand("GetUserNameByID", scon))
            {
                scmd.Parameters.Add(new SqlParameter("@uid", uid));
                scmd.CommandType = CommandType.StoredProcedure;
                name = scmd.ExecuteScalar().ToString();
            }

            return name;
        }

       
       
        //to check whether the user is valid or not during login
        public bool ValidateUser(Credentials c)
        {

            bool flag = true;
            string digestPassword = EncryptPassword(c.password);
            try
            {
                using (SqlDataAdapter sda = new SqlDataAdapter("GetUserCredentials", scon))
                {
                   
                    SqlCommand scmd = new SqlCommand("GetUserCredentials", scon);
                    scmd.Parameters.Add(new SqlParameter("@uid", c.uid));
                    scmd.Parameters.Add(new SqlParameter("@pass", digestPassword));
                    scmd.CommandType = CommandType.StoredProcedure;
                    sda.SelectCommand = scmd;
                    DataSet ds = new DataSet();
                    sda.Fill(ds, "UserName");
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        flag = true;
                    }
                    else
                    {
                        flag = false;
                    }

                }
            
            }
            catch (Exception)
            {
                flag = false;
            }
            return flag;
        }


        //to update password in database when user changed his password
        //using stored procedure UpdatePassword
        public bool ChangePassword(Credentials c)
        {
            bool flag = true;
            string digestPassword = EncryptPassword(c.password);
           // string s = "update user_login set pwd='" + digestPassword + "' where [uid]='" + c.uid + "'";        
            try
            {
                using (SqlDataAdapter sda = new SqlDataAdapter())
                {

                    SqlCommand scmd = new SqlCommand("UpdatePassword",scon);
                    scmd.Parameters.Add(new SqlParameter("@uid",c.uid));
                    scmd.Parameters.Add(new SqlParameter("@pass",digestPassword));
                    scmd.CommandType = CommandType.StoredProcedure;
                    sda.SelectCommand = scmd;
                    DataSet ds = new DataSet();
                    sda.Fill(ds);

                }

            }
            catch (Exception)
            {
                flag = false;

            }
            return flag;

        }


        //to check whether the user is valid or not for visa cacenllation
        public bool ValidateUserDetails(User u)
        {
            bool flag = true;
            string s = "select [uid],email,que,ans from user_details where [uid]='" + u.Uid + "' and email='" + u.Email + "' and que='" + u.Question + "' and ans='" + u.Answer + "'";
            try
            {
                using (SqlDataAdapter sda = new SqlDataAdapter(s, scon))
                {
                    DataSet ds = new DataSet();
                    sda.Fill(ds);
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        flag = true;
                    }
                    else
                    {
                        flag = false;
                    }
                }
            }
            catch (Exception)
            {
                flag = false;
            }

            return flag;
        }


        //to update password in database when user forgot his password
        public bool updateforgotpassword(Credentials c)
        {
          
            bool flag = false;

            string digestPassword = EncryptPassword(c.password);

            string s = "update user_login set pwd='" + digestPassword + "' where [uid]='" + c.uid + "'";
            try
            {
                using (SqlDataAdapter sda = new SqlDataAdapter(s, scon))
                {
                    DataSet ds = new DataSet();
                    sda.Fill(ds);
                    flag = true;
                }

            }
            catch (Exception)
            {
                flag = false;

            }
            return flag;
        }



        //to insert values in database during user registration
        #region RegisterUser
        public Credentials RegisterUser(User user)
        {
            string previousID = "";
            Credentials credit = new Credentials();
            using (SqlDataAdapter sda1 = new SqlDataAdapter("select TOP 1 [uid] from user_details order by [uid] desc", scon))
            {

                DataSet ds1 = new DataSet();
                sda1.Fill(ds1);
                if (ds1.Tables[0].Rows.Count == 0)
                    previousID = "";
                else
                    previousID = ds1.Tables[0].Rows[0]["uid"].ToString();
            }

            Credentials c = new Credentials();
            credit = c.GenerateCredentials(previousID);

            string digestPassword = EncryptPassword(credit.password);

          
            string sql = String.Format("insert into user_details (uid,email,fname,lname,dob,address,contact,qualification,gender,que,ans)"
                + "values('" + credit.uid + "','" + user.Email + "','" + user.Fname + "','" + user.Lname + "','" + user.Dob + "','" + user.Address + "','" + user.Contact + "','" + user.Qualification + "','" + user.Gender + "','" + user.Question + "','" + user.Answer + "')");
            SqlDataAdapter sda = new SqlDataAdapter(sql, scon);

            DataSet ds = new DataSet();

            sda.Fill(ds, "Register");

            sql = string.Format("insert into user_login(uid,pwd) values('" + credit.uid + "','" + digestPassword + "')");
            sda = new SqlDataAdapter(sql, scon);
            sda.Fill(ds, "UserLogin");

            return credit;



        }
        #endregion


        //to get user details from database with the help of user id
        #region GetUserById
        public User GetUserById(string uid)
        {
            User user = new User();
            string sql = "select * from user_details where uid='" + uid + "'";
            try
            {
                using (SqlDataAdapter sda = new SqlDataAdapter(sql, scon))
                {
                    DataSet ds = new DataSet();
                    sda.Fill(ds, "User");

                    user.Uid = ds.Tables["User"].Rows[0]["uid"].ToString();
                    user.Email = ds.Tables["User"].Rows[0]["email"].ToString();
                    user.Fname = ds.Tables["User"].Rows[0]["fname"].ToString();
                    user.Lname = ds.Tables["User"].Rows[0]["lname"].ToString();

                    user.Address = ds.Tables["User"].Rows[0]["address"].ToString();
                    user.Qualification = ds.Tables["User"].Rows[0]["qualification"].ToString();
                    user.Gender = ds.Tables["User"].Rows[0]["gender"].ToString();

                    user.Question = ds.Tables["User"].Rows[0]["que"].ToString();
                    user.Answer = ds.Tables["User"].Rows[0]["ans"].ToString();
                    user.Contact = ds.Tables["User"].Rows[0]["contact"].ToString();
                    user.Dob = Convert.ToDateTime(ds.Tables["User"].Rows[0]["dob"]);

                }
            }
            catch (Exception)
            {
                user.Uid = "error";
            }

            return user;
        }
        #endregion


        #region GetAllUsers
        public List<User> GetAllUsers()
        {
            List<User> list = new List<User>();
            User user;
            DataSet ds = new DataSet();
            string sql = "select * from user_details";
            using (SqlDataAdapter sda = new SqlDataAdapter(sql, scon))
            {
                DataSet ds1 = new DataSet();
                sda.Fill(ds1, "AllUser");
                for (int i = 0; i < ds1.Tables["AllUser"].Rows.Count; i++)
                {
                    user = new User();
                    user.Uid = ds1.Tables["AllUser"].Rows[i]["uid"].ToString();
                    user.Fname = ds1.Tables["AllUser"].Rows[i]["fname"].ToString();
                    user.Lname = ds1.Tables["AllUser"].Rows[i]["lname"].ToString();
                    list.Add(user);

                }
            }
            return list;
        }

        #endregion


    }

}
