﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace MainDllLibrary
{
    public class GenerateFields
    {
        SqlConnection con;
        public GenerateFields()
        {

        }

        //to open sql connection
        public void OpenConnection(string cn)
        {
            con = new SqlConnection(cn);
            con.Open();
        }

        //to close sql connection
        public void CloseConnection()
        {
            con.Close();
        }

        //to retrieve states from database
        public DataSet GetStates()
        {

            using (SqlDataAdapter sda = new SqlDataAdapter("select * from [state] order by sname asc", con))
            {
                DataSet ds = new DataSet();
                sda.Fill(ds);
                return ds;
            }
        }


        //to retrieve cities from database based on selected state
        public DataSet GetCities(string id)
        {
            DataSet ds = new DataSet();
            using (SqlDataAdapter sda = new SqlDataAdapter("select * from cities where sid = '" + id + "'", con))
            {

                sda.Fill(ds, "cities");
                return ds;
            }
        }


        //to retrieve countries from database
        public DataSet GetCountries()
        {
            DataSet ds = new DataSet();
            using (SqlDataAdapter sda = new SqlDataAdapter("select * from countries where cname not like 'india'", con))
            {

                sda.Fill(ds, "countries");
                return ds;
            }
        }

        //to retrieve occupation from database
        public DataSet GetOccupation()
        {
            DataSet ds = new DataSet();
            using (SqlDataAdapter sda = new SqlDataAdapter("select distinct occname from occupation", con))
            {

                sda.Fill(ds, "occupation");
                return ds;
            }
        }
    }
}
