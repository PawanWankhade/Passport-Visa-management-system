﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using MainDllLibrary;
using System.Data.SqlClient;

public partial class Register : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void CheckDate(object source, ServerValidateEventArgs e)
    {
        DateTime dt = Convert.ToDateTime(txtDob.Text);
        if (dt.CompareTo(DateTime.Now) != 1)
        {
            e.IsValid = true;
        }
        else
        {
            e.IsValid = false;
        }
    }


    protected void btnSave_Click1(object sender, EventArgs e)
    {
        Credentials credit = new Credentials();
        bool flag = true;
        if (IsValid)
        {
            User user = new User();
            user.Address = txtAddress.Text;
            user.Answer = txtAnswer.Text;
            user.Contact = txtContact.Text;
            user.Fname = txtFname.Text;
            user.Lname = txtLname.Text;
            user.Email = txtEmail.Text;
            user.Gender = RadioButtonList1.SelectedItem.Text;
            user.Dob = Convert.ToDateTime(txtDob.Text);
            user.Qualification = dropQualification.SelectedItem.Text;
            user.Question = dropHint.SelectedItem.Text;

            UserConnection ucon = new UserConnection();
            try
            {
                string s = ConfigurationManager.ConnectionStrings["pvmConnection"].ConnectionString;
                ucon.OpenConnection(s);
                credit = ucon.RegisterUser(user);
            }
            catch (Exception)
            {
                txtEmail.Focus();
                Label1.Text = "This Email id is already registered";
                Label1.ForeColor = System.Drawing.Color.Red;
                flag = false;
              
            }

            finally
            {
                ucon.CloseConnection();
            }

            if (flag)
            {
                Session["pass"] = credit.password;
                Response.Redirect("~/Success.aspx?type=register&uid=" + credit.uid);


            }


        }
        else
        {
            CustomValidator1.ErrorMessage = "Please Enter valid date of birth";
        }

    }
    protected void btnCancle_Click(object sender, EventArgs e)
    {
       Response.Redirect("Default.aspx");
    }
}